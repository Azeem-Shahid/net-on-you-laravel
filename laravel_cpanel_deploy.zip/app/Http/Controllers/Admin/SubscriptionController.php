<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Subscription;
use App\Models\User;
use App\Models\AdminActivityLog;
use Illuminate\Http\Request;
use Carbon\Carbon;

class SubscriptionController extends Controller
{
    /**
     * Display a listing of subscriptions
     */
    public function index(Request $request)
    {
        $query = Subscription::with(['user']);

        // Search
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('plan_name', 'like', "%{$search}%")
                  ->orWhereHas('user', function ($userQuery) use ($search) {
                      $userQuery->where('name', 'like', "%{$search}%")
                               ->orWhere('email', 'like', "%{$search}%");
                  });
            });
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filter by plan
        if ($request->filled('plan')) {
            $query->where('plan_name', $request->plan);
        }

        // Filter by date range
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $subscriptions = $query->orderBy('created_at', 'desc')
            ->paginate(25);

        // Get summary statistics
        $summary = $this->getSubscriptionSummary($request);

        // Log subscription listing access
        AdminActivityLog::log(
            auth()->id(),
            'view_subscriptions',
            'subscription_list',
            null,
            ['filters' => $request->all()]
        );

        return view('admin.subscriptions.index', compact('subscriptions', 'summary'));
    }

    /**
     * Show subscription details
     */
    public function show(Subscription $subscription)
    {
        $subscription->load(['user', 'transaction']);

        // Log subscription view
        AdminActivityLog::log(
            auth()->id(),
            'view_subscription',
            'subscription',
            $subscription->id,
            [
                'user_id' => $subscription->user_id,
                'plan_name' => $subscription->plan_name,
                'status' => $subscription->status
            ]
        );

        return view('admin.subscriptions.show', compact('subscription'));
    }

    /**
     * Create new subscription manually
     */
    public function create()
    {
        $users = User::where('status', 'active')->get();
        $plans = ['monthly', 'annual'];

        return view('admin.subscriptions.create', compact('users', 'plans'));
    }

    /**
     * Store new subscription
     */
    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
            'plan_name' => 'required|in:monthly,annual',
            'start_date' => 'required|date',
            'duration_days' => 'required|integer|min:1|max:3650', // Max 10 years
            'notes' => 'nullable|string|max:500'
        ]);

        $user = User::findOrFail($request->user_id);

        // Cancel any existing active subscriptions
        Subscription::where('user_id', $user->id)
            ->where('status', 'active')
            ->update(['status' => 'cancelled']);

        // Create new subscription
        $subscription = Subscription::create([
            'user_id' => $user->id,
            'plan_name' => $request->plan_name,
            'start_date' => $request->start_date,
            'end_date' => Carbon::parse($request->start_date)->addDays($request->duration_days),
            'status' => 'active',
            'last_renewed_at' => now()
        ]);

        // Log subscription creation
        AdminActivityLog::log(
            auth()->id(),
            'create_subscription',
            'subscription',
            $subscription->id,
            [
                'user_id' => $user->id,
                'plan_name' => $request->plan_name,
                'duration_days' => $request->duration_days,
                'notes' => $request->notes
            ]
        );

        return redirect()->route('admin.subscriptions.show', $subscription)
            ->with('success', 'Subscription created successfully.');
    }

    /**
     * Edit subscription
     */
    public function edit(Subscription $subscription)
    {
        $plans = ['monthly', 'annual'];
        
        return view('admin.subscriptions.edit', compact('subscription', 'plans'));
    }

    /**
     * Update subscription
     */
    public function update(Request $request, Subscription $subscription)
    {
        $request->validate([
            'plan_name' => 'required|in:monthly,annual',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'status' => 'required|in:active,expired,cancelled',
            'notes' => 'nullable|string|max:500'
        ]);

        $oldData = $subscription->toArray();

        $subscription->update([
            'plan_name' => $request->plan_name,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'status' => $request->status,
            'last_renewed_at' => $request->status === 'active' ? now() : $subscription->last_renewed_at
        ]);

        // Log subscription update
        AdminActivityLog::log(
            auth()->id(),
            'update_subscription',
            'subscription',
            $subscription->id,
            [
                'old_data' => $oldData,
                'new_data' => $subscription->toArray(),
                'notes' => $request->notes
            ]
        );

        return redirect()->route('admin.subscriptions.show', $subscription)
            ->with('success', 'Subscription updated successfully.');
    }

    /**
     * Extend subscription
     */
    public function extend(Request $request, Subscription $subscription)
    {
        $request->validate([
            'days' => 'required|integer|min:1|max:365'
        ]);

        $oldEndDate = $subscription->end_date;
        $subscription->extend($request->days);

        // Log subscription extension
        AdminActivityLog::log(
            auth()->id(),
            'extend_subscription',
            'subscription',
            $subscription->id,
            [
                'old_end_date' => $oldEndDate,
                'new_end_date' => $subscription->end_date,
                'days_added' => $request->days
            ]
        );

        return response()->json([
            'success' => true,
            'message' => "Subscription extended by {$request->days} days",
            'new_end_date' => $subscription->end_date->format('Y-m-d')
        ]);
    }

    /**
     * Cancel subscription
     */
    public function cancel(Subscription $subscription)
    {
        $subscription->cancel();

        // Log subscription cancellation
        AdminActivityLog::log(
            auth()->id(),
            'cancel_subscription',
            'subscription',
            $subscription->id,
            [
                'user_id' => $subscription->user_id,
                'plan_name' => $subscription->plan_name
            ]
        );

        return response()->json([
            'success' => true,
            'message' => 'Subscription cancelled successfully'
        ]);
    }

    /**
     * Get subscription summary statistics
     */
    private function getSubscriptionSummary(Request $request): array
    {
        $query = Subscription::query();

        // Apply same filters
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('plan')) {
            $query->where('plan_name', $request->plan);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $totalSubscriptions = $query->count();
        $activeSubscriptions = (clone $query)->where('status', 'active')->where('end_date', '>', now())->count();
        $expiredSubscriptions = (clone $query)->where('status', 'active')->where('end_date', '<=', now())->count();
        $cancelledSubscriptions = (clone $query)->where('status', 'cancelled')->count();

        // Get plan distribution
        $planDistribution = (clone $query)
            ->selectRaw('plan_name, COUNT(*) as count')
            ->groupBy('plan_name')
            ->get();

        // Get expiring soon subscriptions
        $expiringSoon = (clone $query)
            ->where('status', 'active')
            ->where('end_date', '>', now())
            ->where('end_date', '<=', now()->addDays(7))
            ->count();

        return [
            'total_subscriptions' => $totalSubscriptions,
            'active_subscriptions' => $activeSubscriptions,
            'expired_subscriptions' => $expiredSubscriptions,
            'cancelled_subscriptions' => $cancelledSubscriptions,
            'plan_distribution' => $planDistribution,
            'expiring_soon' => $expiringSoon,
        ];
    }

    /**
     * Export subscriptions to CSV
     */
    public function export(Request $request)
    {
        $query = Subscription::with('user');

        // Apply same filters as index
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('plan')) {
            $query->where('plan_name', $request->plan);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $subscriptions = $query->orderBy('created_at', 'desc')->get();

        $filename = 'subscriptions_' . now()->format('Y-m-d_H-i-s') . '.csv';
        
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ];

        $callback = function() use ($subscriptions) {
            $file = fopen('php://output', 'w');
            
            // Headers
            fputcsv($file, [
                'ID', 'User', 'Email', 'Plan', 'Start Date', 'End Date', 'Status',
                'Last Renewed', 'Created At', 'Updated At'
            ]);

            // Data
            foreach ($subscriptions as $subscription) {
                fputcsv($file, [
                    $subscription->id,
                    $subscription->user->name ?? 'N/A',
                    $subscription->user->email ?? 'N/A',
                    $subscription->plan_name,
                    $subscription->start_date,
                    $subscription->end_date,
                    $subscription->status,
                    $subscription->last_renewed_at,
                    $subscription->created_at,
                    $subscription->updated_at
                ]);
            }

            fclose($file);
        };

        // Log export
        AdminActivityLog::log(
            auth()->id(),
            'export_subscriptions',
            'subscription_export',
            null,
            ['count' => $subscriptions->count(), 'filters' => $request->all()]
        );

        return response()->stream($callback, 200, $headers);
    }
}
