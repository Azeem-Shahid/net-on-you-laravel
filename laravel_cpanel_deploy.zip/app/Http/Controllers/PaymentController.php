<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use App\Models\Subscription;
use App\Models\PaymentNotification;
use App\Models\Setting;
use App\Services\ReferralService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PaymentController extends Controller
{
    /**
     * Show payment checkout form
     */
    public function checkout(Request $request)
    {
        $plans = [
            'monthly' => [
                'name' => 'Monthly Plan',
                'price' => 29.99,
                'duration' => 30,
                'description' => 'Access to all magazines for 30 days'
            ],
            'annual' => [
                'name' => 'Annual Plan',
                'price' => 299.99,
                'duration' => 365,
                'description' => 'Access to all magazines for 1 year (Save 17%)'
            ]
        ];

        $selectedPlan = $request->get('plan', 'monthly');
        
        return view('payment.checkout', compact('plans', 'selectedPlan'));
    }

    /**
     * Initiate payment
     */
    public function initiate(Request $request)
    {
        $request->validate([
            'plan' => 'required|in:monthly,annual',
            'payment_method' => 'required|in:crypto,manual'
        ]);

        $plans = [
            'monthly' => ['price' => 29.99, 'duration' => 30],
            'annual' => ['price' => 299.99, 'duration' => 365]
        ];

        $plan = $plans[$request->plan];
        $user = auth()->user();

        // Check if user already has active subscription
        if ($user->hasActiveSubscription()) {
            return back()->with('error', 'You already have an active subscription.');
        }

        // Create transaction
        $transaction = Transaction::create([
            'user_id' => $user->id,
            'amount' => $plan['price'],
            'currency' => 'USDT',
            'gateway' => $request->payment_method === 'crypto' ? 'nowpayments' : 'manual',
            'status' => 'pending',
            'notes' => "Subscription payment for {$request->plan} plan",
            'meta' => [
                'plan' => $request->plan,
                'duration_days' => $plan['duration'],
                'payment_method' => $request->payment_method
            ]
        ]);

        if ($request->payment_method === 'crypto') {
            return $this->initiateCryptoPayment($transaction);
        } else {
            return $this->initiateManualPayment($transaction);
        }
    }

    /**
     * Initiate crypto payment
     */
    private function initiateCryptoPayment(Transaction $transaction)
    {
        // Get API key from settings
        $apiKey = Setting::where('key', 'nowpayments_api_key')->value('value');
        
        if (!$apiKey) {
            Log::error('NowPayments API key not configured');
            return back()->with('error', 'Payment service temporarily unavailable.');
        }

        try {
            // Create payment request to NowPayments
            $response = $this->createNowPaymentsPayment($transaction, $apiKey);
            
            if (isset($response['payment_id'])) {
                $transaction->update([
                    'meta' => array_merge($transaction->meta ?? [], [
                        'payment_id' => $response['payment_id'],
                        'payment_url' => $response['payment_url'] ?? null,
                        'payment_address' => $response['pay_address'] ?? null
                    ])
                ]);

                return redirect()->route('payment.status', $transaction)
                    ->with('success', 'Payment initiated successfully. Please complete the payment.');
            } else {
                Log::error('NowPayments payment creation failed', $response);
                return back()->with('error', 'Failed to create payment. Please try again.');
            }
        } catch (\Exception $e) {
            Log::error('NowPayments API error', ['error' => $e->getMessage()]);
            return back()->with('error', 'Payment service error. Please try again.');
        }
    }

    /**
     * Create NowPayments payment
     */
    private function createNowPaymentsPayment(Transaction $transaction, string $apiKey)
    {
        $url = 'https://api.nowpayments.io/v1/payment';
        
        $data = [
            'price_amount' => $transaction->amount,
            'price_currency' => 'usd',
            'pay_currency' => 'usdt',
            'ipn_callback_url' => route('payment.webhook'),
            'order_id' => $transaction->id,
            'order_description' => $transaction->notes,
            'is_fixed_rate' => true,
            'is_fee_paid_by_user' => false
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'x-api-key: ' . $apiKey,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            throw new \Exception("NowPayments API returned HTTP {$httpCode}");
        }

        return json_decode($response, true);
    }

    /**
     * Initiate manual payment
     */
    private function initiateManualPayment(Transaction $transaction)
    {
        return redirect()->route('payment.manual', $transaction)
            ->with('success', 'Please upload your payment proof.');
    }

    /**
     * Show payment status
     */
    public function status(Transaction $transaction)
    {
        // Ensure user can only view their own transactions
        if ($transaction->user_id !== auth()->id()) {
            abort(403);
        }

        return view('payment.status', compact('transaction'));
    }

    /**
     * Show manual payment form
     */
    public function manual(Transaction $transaction)
    {
        // Ensure user can only view their own transactions
        if ($transaction->user_id !== auth()->id()) {
            abort(403);
        }

        return view('payment.manual', compact('transaction'));
    }

    /**
     * Handle manual payment proof upload
     */
    public function uploadProof(Request $request, Transaction $transaction)
    {
        // Ensure user can only upload for their own transactions
        if ($transaction->user_id !== auth()->id()) {
            abort(403);
        }

        $request->validate([
            'proof_file' => 'required|file|mimes:jpg,jpeg,png,pdf|max:2048',
            'notes' => 'nullable|string|max:500'
        ]);

        $file = $request->file('proof_file');
        $filename = 'payment_proof_' . $transaction->id . '_' . time() . '.' . $file->getClientOriginalExtension();
        
        // Store file in storage/app/public/payment_proofs
        $path = $file->storeAs('payment_proofs', $filename, 'public');

        $transaction->update([
            'notes' => $request->notes ?? 'Payment proof uploaded',
            'meta' => array_merge($transaction->meta ?? [], [
                'proof_file' => $path,
                'uploaded_at' => now()->toISOString()
            ])
        ]);

        return redirect()->route('payment.status', $transaction)
            ->with('success', 'Payment proof uploaded successfully. Admin will review and approve.');
    }

    /**
     * Handle payment webhook
     */
    public function webhook(Request $request)
    {
        Log::info('Payment webhook received', $request->all());

        // Store webhook notification
        PaymentNotification::create([
            'payload' => $request->all(),
            'received_at' => now(),
            'processed' => false
        ]);

        try {
            $this->processWebhook($request);
            
            return response()->json(['status' => 'ok']);
        } catch (\Exception $e) {
            Log::error('Webhook processing failed', ['error' => $e->getMessage()]);
            return response()->json(['status' => 'error'], 500);
        }
    }

    /**
     * Process webhook data
     */
    private function processWebhook(Request $request)
    {
        $paymentId = $request->input('payment_id');
        $status = $request->input('payment_status');
        $transactionHash = $request->input('pay_address');

        // Find transaction by payment_id in meta
        $transaction = Transaction::whereJsonContains('meta->payment_id', $paymentId)->first();
        
        if (!$transaction) {
            Log::warning('Transaction not found for payment_id', ['payment_id' => $paymentId]);
            return;
        }

        // Update transaction status
        $newStatus = $this->mapPaymentStatus($status);
        $transaction->update([
            'status' => $newStatus,
            'transaction_hash' => $transactionHash,
            'meta' => array_merge($transaction->meta ?? [], [
                'webhook_status' => $status,
                'processed_at' => now()->toISOString()
            ])
        ]);

        // If payment completed, activate subscription
        if ($newStatus === 'completed') {
            $this->activateSubscription($transaction);
        }

        // Mark notification as processed
        PaymentNotification::where('payload->payment_id', $paymentId)
            ->update(['processed' => true]);
    }

    /**
     * Map NowPayments status to our status
     */
    private function mapPaymentStatus(string $nowPaymentsStatus): string
    {
        $statusMap = [
            'waiting' => 'pending',
            'confirming' => 'pending',
            'confirmed' => 'completed',
            'sending' => 'pending',
            'partially_paid' => 'pending',
            'finished' => 'completed',
            'failed' => 'failed',
            'cancelled' => 'cancelled',
            'expired' => 'failed'
        ];

        return $statusMap[$nowPaymentsStatus] ?? 'pending';
    }

    /**
     * Activate subscription for completed transaction
     */
    private function activateSubscription(Transaction $transaction)
    {
        DB::transaction(function () use ($transaction) {
            $plan = $transaction->meta['plan'] ?? 'monthly';
            $durationDays = $transaction->meta['duration_days'] ?? 30;

            // Cancel any existing active subscriptions
            Subscription::where('user_id', $transaction->user_id)
                ->where('status', 'active')
                ->update(['status' => 'cancelled']);

            // Create new subscription
            Subscription::create([
                'user_id' => $transaction->user_id,
                'plan_name' => $plan,
                'start_date' => now(),
                'end_date' => now()->addDays($durationDays),
                'status' => 'active',
                'last_renewed_at' => now()
            ]);

            // Update transaction meta
            $transaction->update([
                'meta' => array_merge($transaction->meta ?? [], [
                    'subscription_activated' => true,
                    'subscription_activated_at' => now()->toISOString()
                ])
            ]);

            // Generate commissions for this transaction
            try {
                $referralService = app(ReferralService::class);
                $referralService->generateCommissions($transaction);
            } catch (\Exception $e) {
                Log::error("Failed to generate commissions for transaction {$transaction->id}: " . $e->getMessage());
                // Don't fail the subscription activation if commission generation fails
            }
        });
    }

    /**
     * Show payment history
     */
    public function history()
    {
        $transactions = auth()->user()->transactions()
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('payment.history', compact('transactions'));
    }
}
