@extends('admin.layouts.app')

@section('title', 'Edit User')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.users.index') }}">Users</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.users.show', $user) }}">{{ $user->name }}</a></li>
                        <li class="breadcrumb-item active">Edit User</li>
                    </ol>
                </div>
                <h4 class="page-title">Edit User: {{ $user->name }}</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('admin.users.update', $user) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                           id="name" name="name" value="{{ old('name', $user->name) }}" required>
                                    @error('name')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control @error('email') is-invalid @enderror" 
                                           id="email" name="email" value="{{ old('email', $user->email) }}" required>
                                    @error('email')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                                    <select class="form-select @error('status') is-invalid @enderror" 
                                            id="status" name="status" required>
                                        <option value="">Select Status</option>
                                        <option value="active" {{ old('status', $user->status) === 'active' ? 'selected' : '' }}>
                                            Active
                                        </option>
                                        <option value="inactive" {{ old('status', $user->status) === 'inactive' ? 'selected' : '' }}>
                                            Inactive
                                        </option>
                                        <option value="blocked" {{ old('status', $user->status) === 'blocked' ? 'selected' : '' }}>
                                            Blocked
                                        </option>
                                    </select>
                                    @error('status')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="language" class="form-label">Language</label>
                                    <select class="form-select" id="language" name="language">
                                        <option value="">Select Language</option>
                                        <option value="en" {{ old('language', $user->language) === 'en' ? 'selected' : '' }}>
                                            English
                                        </option>
                                        <option value="es" {{ old('language', $user->language) === 'es' ? 'selected' : '' }}>
                                            Spanish
                                        </option>
                                        <option value="fr" {{ old('language', $user->language) === 'fr' ? 'selected' : '' }}>
                                            French
                                        </option>
                                        <option value="de" {{ old('language', $user->language) === 'de' ? 'selected' : '' }}>
                                            German
                                        </option>
                                        <option value="it" {{ old('language', $user->language) === 'it' ? 'selected' : '' }}>
                                            Italian
                                        </option>
                                        <option value="pt" {{ old('language', $user->language) === 'pt' ? 'selected' : '' }}>
                                            Portuguese
                                        </option>
                                        <option value="ru" {{ old('language', $user->language) === 'ru' ? 'selected' : '' }}>
                                            Russian
                                        </option>
                                        <option value="zh" {{ old('language', $user->language) === 'zh' ? 'selected' : '' }}>
                                            Chinese
                                        </option>
                                        <option value="ja" {{ old('language', $user->language) === 'ja' ? 'selected' : '' }}>
                                            Japanese
                                        </option>
                                        <option value="ko" {{ old('language', $user->language) === 'ko' ? 'selected' : '' }}>
                                            Korean
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="subscription_start_date" class="form-label">Subscription Start Date</label>
                                    <input type="date" class="form-control @error('subscription_start_date') is-invalid @enderror" 
                                           id="subscription_start_date" name="subscription_start_date" 
                                           value="{{ old('subscription_start_date', $user->subscription_start_date ? $user->subscription_start_date->format('Y-m-d') : '') }}">
                                    @error('subscription_start_date')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="subscription_end_date" class="form-label">Subscription End Date</label>
                                    <input type="date" class="form-control @error('subscription_end_date') is-invalid @enderror" 
                                           id="subscription_end_date" name="subscription_end_date" 
                                           value="{{ old('subscription_end_date', $user->subscription_end_date ? $user->subscription_end_date->format('Y-m-d') : '') }}">
                                    @error('subscription_end_date')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="wallet_address" class="form-label">Wallet Address</label>
                            <input type="text" class="form-control" id="wallet_address" name="wallet_address" 
                                   value="{{ old('wallet_address', $user->wallet_address) }}" 
                                   placeholder="Enter wallet address">
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Email Verification</label>
                                    <div class="d-flex align-items-center">
                                        @if($user->hasVerifiedEmail())
                                            <span class="badge bg-success me-2">Verified</span>
                                            <small class="text-muted">{{ $user->email_verified_at->format('M d, Y H:i') }}</small>
                                        @else
                                            <span class="badge bg-warning me-2">Not Verified</span>
                                            <button type="button" class="btn btn-sm btn-outline-warning" 
                                                    onclick="resendVerification({{ $user->id }})">
                                                Resend
                                            </button>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Last Login</label>
                                    <div class="d-flex align-items-center">
                                        @if($user->last_login_at)
                                            <span class="text-muted">{{ $user->last_login_at->format('M d, Y H:i') }}</span>
                                        @else
                                            <span class="text-muted">Never</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Referrer</label>
                                    <div class="d-flex align-items-center">
                                        @if($user->referrer)
                                            <a href="{{ route('admin.users.show', $user->referrer) }}" class="text-decoration-none">
                                                {{ $user->referrer->name }}
                                            </a>
                                        @else
                                            <span class="text-muted">None</span>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Referrals Count</label>
                                    <div class="d-flex align-items-center">
                                        <span class="badge bg-info">{{ $user->referrals->count() }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Total Transactions</label>
                                    <div class="d-flex align-items-center">
                                        <span class="badge bg-primary">{{ $user->transactions->count() }}</span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Total Commissions</label>
                                    <div class="d-flex align-items-center">
                                        <span class="badge bg-success">{{ $user->commissionsEarned->sum('amount') }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between">
                            <a href="{{ route('admin.users.show', $user) }}" class="btn btn-secondary">
                                <i class="mdi mdi-arrow-left"></i> Back to User
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="mdi mdi-content-save"></i> Update User
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function resendVerification(userId) {
    if (confirm('Resend verification email to this user?')) {
        fetch(`/admin/users/${userId}/resend-verification`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Content-Type': 'application/json',
            },
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Verification email sent successfully!');
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing your request.');
        });
    }
}

// Date validation
document.getElementById('subscription_end_date').addEventListener('change', function() {
    const startDate = document.getElementById('subscription_start_date').value;
    const endDate = this.value;
    
    if (startDate && endDate && startDate > endDate) {
        alert('Subscription end date must be after start date');
        this.value = '';
    }
});
</script>
@endpush
