@extends('admin.layouts.app')

@section('title', 'User Details')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.users.index') }}">Users</a></li>
                        <li class="breadcrumb-item active">User Details</li>
                    </ol>
                </div>
                <h4 class="page-title">User Details</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- User Profile Card -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="text-center">
                        <div class="avatar-lg mx-auto mb-3">
                            <div class="avatar-title bg-primary rounded-circle text-white font-24">
                                {{ strtoupper(substr($user->name, 0, 1)) }}
                            </div>
                        </div>
                        <h4 class="mb-1">{{ $user->name }}</h4>
                        <p class="text-muted">{{ $user->email }}</p>
                        
                        <div class="mb-3">
                            <span class="badge bg-{{ $user->status === 'active' ? 'success' : ($user->status === 'blocked' ? 'danger' : 'warning') }} fs-6">
                                {{ ucfirst($user->status) }}
                            </span>
                        </div>

                        <div class="row text-center">
                            <div class="col-6">
                                <h5 class="mb-1">{{ $user->referrals->count() }}</h5>
                                <small class="text-muted">Referrals</small>
                            </div>
                            <div class="col-6">
                                <h5 class="mb-1">{{ $user->transactions->count() }}</h5>
                                <small class="text-muted">Transactions</small>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="mt-3">
                        <h6 class="text-uppercase">Profile Information</h6>
                        <div class="row">
                            <div class="col-6">
                                <p class="mb-1 text-muted">Language</p>
                                <p class="mb-3">{{ $user->language ?? 'Not set' }}</p>
                            </div>
                            <div class="col-6">
                                <p class="mb-1 text-muted">Wallet Address</p>
                                <p class="mb-3 text-break">{{ $user->wallet_address ?? 'Not set' }}</p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <p class="mb-1 text-muted">Subscription Start</p>
                                <p class="mb-3">{{ $user->subscription_start_date ? $user->subscription_start_date->format('M d, Y') : 'Not set' }}</p>
                            </div>
                            <div class="col-6">
                                <p class="mb-1 text-muted">Subscription End</p>
                                <p class="mb-3">{{ $user->subscription_end_date ? $user->subscription_end_date->format('M d, Y') : 'Not set' }}</p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <p class="mb-1 text-muted">Referrer</p>
                                <p class="mb-3">
                                    @if($user->referrer)
                                        <a href="{{ route('admin.users.show', $user->referrer) }}">{{ $user->referrer->name }}</a>
                                    @else
                                        None
                                    @endif
                                </p>
                            </div>
                            <div class="col-6">
                                <p class="mb-1 text-muted">Joined</p>
                                <p class="mb-3">{{ $user->created_at->format('M d, Y') }}</p>
                            </div>
                        </div>
                    </div>

                    <div class="mt-3">
                        <a href="{{ route('admin.users.edit', $user) }}" class="btn btn-primary btn-sm w-100 mb-2">
                            <i class="mdi mdi-pencil"></i> Edit User
                        </a>
                        
                        <button type="button" class="btn btn-{{ $user->status === 'blocked' ? 'success' : 'danger' }} btn-sm w-100 mb-2" 
                                onclick="toggleBlock({{ $user->id }})">
                            <i class="mdi mdi-{{ $user->status === 'blocked' ? 'check' : 'block-helper' }}"></i>
                            {{ $user->status === 'blocked' ? 'Unblock User' : 'Block User' }}
                        </button>

                        @if(!$user->hasVerifiedEmail())
                        <button type="button" class="btn btn-warning btn-sm w-100 mb-2" 
                                onclick="resendVerification({{ $user->id }})">
                            <i class="mdi mdi-email"></i> Resend Verification
                        </button>
                        @endif

                        <button type="button" class="btn btn-info btn-sm w-100" 
                                onclick="showResetPasswordModal()">
                            <i class="mdi mdi-key"></i> Reset Password
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- User Activity Tabs -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <ul class="nav nav-tabs nav-bordered" id="userTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="transactions-tab" data-bs-toggle="tab" data-bs-target="#transactions" type="button" role="tab">
                                Transactions ({{ $user->transactions->count() }})
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="commissions-tab" data-bs-toggle="tab" data-bs-target="#commissions" type="button" role="tab">
                                Commissions ({{ $user->commissionsEarned->count() }})
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="magazines-tab" data-bs-toggle="tab" data-bs-target="#magazines" type="button" role="tab">
                                Magazine Access ({{ $user->magazineEntitlements->count() }})
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="referrals-tab" data-bs-toggle="tab" data-bs-target="#referrals" type="button" role="tab">
                                Referrals ({{ $user->referrals->count() }})
                            </button>
                        </li>
                    </ul>

                    <div class="tab-content" id="userTabsContent">
                        <!-- Transactions Tab -->
                        <div class="tab-pane fade show active" id="transactions" role="tabpanel">
                            <div class="table-responsive mt-3">
                                <table class="table table-centered table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Amount</th>
                                            <th>Currency</th>
                                            <th>Gateway</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($user->transactions as $transaction)
                                        <tr>
                                            <td>{{ $transaction->id }}</td>
                                            <td>{{ $transaction->amount }}</td>
                                            <td>{{ $transaction->currency }}</td>
                                            <td>{{ $transaction->gateway }}</td>
                                            <td>
                                                <span class="badge bg-{{ $transaction->status === 'completed' ? 'success' : ($transaction->status === 'pending' ? 'warning' : 'danger') }}">
                                                    {{ ucfirst($transaction->status) }}
                                                </span>
                                            </td>
                                            <td>{{ $transaction->created_at->format('M d, Y H:i') }}</td>
                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="6" class="text-center text-muted">No transactions found</td>
                                        </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Commissions Tab -->
                        <div class="tab-pane fade" id="commissions" role="tabpanel">
                            <div class="table-responsive mt-3">
                                <table class="table table-centered table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Amount</th>
                                            <th>Type</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($user->commissionsEarned as $commission)
                                        <tr>
                                            <td>{{ $commission->id }}</td>
                                            <td>{{ $commission->amount }}</td>
                                            <td>{{ ucfirst($commission->type) }}</td>
                                            <td>
                                                <span class="badge bg-{{ $commission->payout_status === 'paid' ? 'success' : 'warning' }}">
                                                    {{ ucfirst($commission->payout_status) }}
                                                </span>
                                            </td>
                                            <td>{{ $commission->created_at->format('M d, Y H:i') }}</td>
                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="5" class="text-center text-muted">No commissions found</td>
                                        </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Magazines Tab -->
                        <div class="tab-pane fade" id="magazines" role="tabpanel">
                            <div class="table-responsive mt-3">
                                <table class="table table-centered table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Magazine</th>
                                            <th>Access Date</th>
                                            <th>Expiry Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($user->magazineEntitlements as $entitlement)
                                        <tr>
                                            <td>{{ $entitlement->magazine->title ?? 'N/A' }}</td>
                                            <td>{{ $entitlement->created_at->format('M d, Y') }}</td>
                                            <td>{{ $entitlement->expires_at ? $entitlement->expires_at->format('M d, Y') : 'Never' }}</td>
                                            <td>
                                                <span class="badge bg-{{ $entitlement->isExpired() ? 'danger' : 'success' }}">
                                                    {{ $entitlement->isExpired() ? 'Expired' : 'Active' }}
                                                </span>
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="4" class="text-center text-muted">No magazine access found</td>
                                        </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Referrals Tab -->
                        <div class="tab-pane fade" id="referrals" role="tabpanel">
                            <div class="table-responsive mt-3">
                                <table class="table table-centered table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Status</th>
                                            <th>Joined</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($user->referrals as $referral)
                                        <tr>
                                            <td>
                                                <a href="{{ route('admin.users.show', $referral) }}">{{ $referral->name }}</a>
                                            </td>
                                            <td>{{ $referral->email }}</td>
                                            <td>
                                                <span class="badge bg-{{ $referral->status === 'active' ? 'success' : ($referral->status === 'blocked' ? 'danger' : 'warning') }}">
                                                    {{ ucfirst($referral->status) }}
                                                </span>
                                            </td>
                                            <td>{{ $referral->created_at->format('M d, Y') }}</td>
                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="4" class="text-center text-muted">No referrals found</td>
                                        </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Reset Password Modal -->
<div class="modal fade" id="resetPasswordModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Reset User Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="resetPasswordForm">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required minlength="8">
                    </div>
                    <div class="mb-3">
                        <label for="new_password_confirmation" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="new_password_confirmation" name="new_password_confirmation" required minlength="8">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Reset Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
function toggleBlock(userId) {
    if (confirm('Are you sure you want to change this user\'s status?')) {
        fetch(`/admin/users/${userId}/toggle-block`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Content-Type': 'application/json',
            },
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing your request.');
        });
    }
}

function resendVerification(userId) {
    if (confirm('Resend verification email to this user?')) {
        fetch(`/admin/users/${userId}/resend-verification`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Content-Type': 'application/json',
            },
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Verification email sent successfully!');
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing your request.');
        });
    }
}

function showResetPasswordModal() {
    $('#resetPasswordModal').modal('show');
}

document.getElementById('resetPasswordForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const userId = {{ $user->id }};
    
    fetch(`/admin/users/${userId}/reset-password`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Password reset successfully!');
            $('#resetPasswordModal').modal('hide');
            this.reset();
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while processing your request.');
    });
});
</script>
@endpush
