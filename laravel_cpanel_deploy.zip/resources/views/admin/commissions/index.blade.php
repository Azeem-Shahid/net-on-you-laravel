@extends('admin.layouts.app')

@section('title', 'Commission Management - Admin')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="page-header">
        <div class="row align-items-center">
            <div class="col">
                <h3 class="page-title">Commission Management</h3>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Commissions</li>
                </ul>
            </div>
            <div class="col-auto">
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createPayoutBatchModal">
                    <i class="fas fa-plus"></i> Create Payout Batch
                </button>
                <a href="{{ route('admin.commissions.export') }}" class="btn btn-primary">
                    <i class="fas fa-download"></i> Export CSV
                </a>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row">
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0">{{ $stats['total_commissions'] }}</h4>
                            <p class="text-muted mb-0">Total Commissions</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0">${{ number_format($stats['total_amount'], 2) }}</h4>
                            <p class="text-muted mb-0">Total Amount</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0">${{ number_format($stats['eligible_amount'], 2) }}</h4>
                            <p class="text-muted mb-0">Eligible</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0">${{ number_format($stats['pending_payout'], 2) }}</h4>
                            <p class="text-muted mb-0">Pending Payout</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0">${{ number_format($stats['paid_amount'], 2) }}</h4>
                            <p class="text-muted mb-0">Paid</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0">${{ number_format($stats['void_amount'], 2) }}</h4>
                            <p class="text-muted mb-0">Void</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.commissions.index') }}" class="row">
                <div class="col-md-2">
                    <label class="form-label">Month</label>
                    <input type="month" name="month" class="form-control" value="{{ request('month') }}">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Level</label>
                    <select name="level" class="form-select">
                        <option value="">All Levels</option>
                        @for($i = 1; $i <= 6; $i++)
                            <option value="{{ $i }}" {{ request('level') == $i ? 'selected' : '' }}>Level {{ $i }}</option>
                        @endfor
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Eligibility</label>
                    <select name="eligibility" class="form-select">
                        <option value="">All</option>
                        <option value="eligible" {{ request('eligibility') === 'eligible' ? 'selected' : '' }}>Eligible</option>
                        <option value="ineligible" {{ request('eligibility') === 'ineligible' ? 'selected' : '' }}>Ineligible</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Payout Status</label>
                    <select name="payout_status" class="form-select">
                        <option value="">All</option>
                        <option value="pending" {{ request('payout_status') === 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="paid" {{ request('payout_status') === 'paid' ? 'selected' : '' }}>Paid</option>
                        <option value="void" {{ request('payout_status') === 'void' ? 'selected' : '' }}>Void</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Earner ID</label>
                    <input type="number" name="earner_id" class="form-control" value="{{ request('earner_id') }}" placeholder="Earner ID">
                </div>
                <div class="col-md-2">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary d-block w-100">Filter</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Commissions Table -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Earner</th>
                            <th>Source User</th>
                            <th>Level</th>
                            <th>Amount</th>
                            <th>Month</th>
                            <th>Eligibility</th>
                            <th>Payout Status</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($commissions as $commission)
                            <tr>
                                <td>{{ $commission->id }}</td>
                                <td>
                                    <div>
                                        <strong>{{ $commission->earner->name }}</strong>
                                        <br>
                                        <small class="text-muted">ID: {{ $commission->earner->id }}</small>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <strong>{{ $commission->sourceUser->name }}</strong>
                                        <br>
                                        <small class="text-muted">ID: {{ $commission->sourceUser->id }}</small>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-primary">Level {{ $commission->level }}</span>
                                </td>
                                <td>${{ number_format($commission->amount, 2) }}</td>
                                <td>{{ $commission->month }}</td>
                                <td>
                                    @if($commission->eligibility === 'eligible')
                                        <span class="badge bg-success">Eligible</span>
                                    @else
                                        <span class="badge bg-warning">Ineligible</span>
                                    @endif
                                </td>
                                <td>
                                    @if($commission->payout_status === 'pending')
                                        <span class="badge bg-warning">Pending</span>
                                    @elseif($commission->payout_status === 'paid')
                                        <span class="badge bg-success">Paid</span>
                                    @else
                                        <span class="badge bg-danger">Void</span>
                                    @endif
                                </td>
                                <td>{{ $commission->created_at->format('M d, Y H:i') }}</td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="{{ route('admin.commissions.show', $commission) }}" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        @if($commission->payout_status === 'pending')
                                            <button type="button" class="btn btn-sm btn-warning" onclick="showAdjustModal({{ $commission->id }}, {{ $commission->amount }})">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger" onclick="showVoidModal({{ $commission->id }})">
                                                <i class="fas fa-ban"></i>
                                            </button>
                                        @elseif($commission->payout_status === 'void')
                                            <button type="button" class="btn btn-sm btn-success" onclick="showRestoreModal({{ $commission->id }})">
                                                <i class="fas fa-undo"></i>
                                            </button>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="10" class="text-center">No commissions found.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center">
                {{ $commissions->links() }}
            </div>
        </div>
    </div>
</div>

<!-- Create Payout Batch Modal -->
<div class="modal fade" id="createPayoutBatchModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.commissions.create-payout-batch') }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Create Payout Batch</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Month (YYYY-MM)</label>
                        <input type="month" name="month" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notes (Optional)</label>
                        <textarea name="notes" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Create Batch</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Adjust Commission Modal -->
<div class="modal fade" id="adjustCommissionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="adjustCommissionForm" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Adjust Commission Amount</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">New Amount</label>
                        <input type="number" name="new_amount" class="form-control" step="0.01" min="0" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Reason</label>
                        <textarea name="reason" class="form-control" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">Adjust</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Void Commission Modal -->
<div class="modal fade" id="voidCommissionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="voidCommissionForm" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Void Commission</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Reason</label>
                        <textarea name="reason" class="form-control" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Void</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Restore Commission Modal -->
<div class="modal fade" id="restoreCommissionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="restoreCommissionForm" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Restore Commission</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Reason</label>
                        <textarea name="reason" class="form-control" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Restore</button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
function showAdjustModal(commissionId, currentAmount) {
    document.getElementById('adjustCommissionForm').action = `/admin/commissions/${commissionId}/adjust`;
    document.querySelector('#adjustCommissionModal input[name="new_amount"]').value = currentAmount;
    new bootstrap.Modal(document.getElementById('adjustCommissionModal')).show();
}

function showVoidModal(commissionId) {
    document.getElementById('voidCommissionForm').action = `/admin/commissions/${commissionId}/void`;
    new bootstrap.Modal(document.getElementById('voidCommissionModal')).show();
}

function showRestoreModal(commissionId) {
    document.getElementById('restoreCommissionForm').action = `/admin/commissions/${commissionId}/restore`;
    new bootstrap.Modal(document.getElementById('restoreCommissionModal')).show();
}
</script>
@endpush
