<?php $__env->startSection('title', 'Magazines'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="py-6">
                <h1 class="text-3xl font-bold text-gray-900">Magazines</h1>
                <p class="mt-2 text-sm text-gray-600">Access to premium content with your subscription</p>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Search and Filters -->
        <div class="mb-8">
            <form method="GET" action="<?php echo e(route('magazines.index')); ?>" class="space-y-4">
                <!-- Search Bar -->
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                    </div>
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" 
                           class="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                           placeholder="Search magazines by title or description...">
                </div>

                <!-- Filters Row -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <!-- Category Filter -->
                    <div>
                        <label for="category" class="block text-sm font-medium text-gray-700 mb-2">Category</label>
                        <select name="category" id="category" 
                                class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                            <option value="">All Categories</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category); ?>" <?php echo e(request('category') == $category ? 'selected' : ''); ?>>
                                    <?php echo e(ucfirst($category)); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Language Filter -->
                    <div>
                        <label for="language_code" class="block text-sm font-medium text-gray-700 mb-2">Language</label>
                        <select name="language_code" id="language_code" 
                                class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                            <option value="">All Languages</option>
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($language); ?>" <?php echo e(request('language_code') == $language ? 'selected' : ''); ?>>
                                    <?php echo e(strtoupper($language)); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Filter Button -->
                    <div class="flex items-end">
                        <button type="submit" 
                                class="w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
                            Apply Filters
                        </button>
                    </div>
                </div>

                <!-- Clear Filters -->
                <?php if(request('search') || request('category') || request('language_code')): ?>
                    <div class="text-center">
                        <a href="<?php echo e(route('magazines.index')); ?>" 
                           class="text-sm text-purple-600 hover:text-purple-700 font-medium">
                            Clear all filters
                        </a>
                    </div>
                <?php endif; ?>
            </form>
        </div>

        <!-- Results Count -->
        <div class="mb-6">
            <p class="text-sm text-gray-600">
                Showing <?php echo e($magazines->firstItem() ?? 0); ?> to <?php echo e($magazines->lastItem() ?? 0); ?> 
                of <?php echo e($magazines->total()); ?> magazines
            </p>
        </div>

        <!-- Magazines Grid -->
        <?php if($magazines->count() > 0): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                <?php $__currentLoopData = $magazines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $magazine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
                        <!-- Cover Image -->
                        <div class="aspect-[3/4] bg-gray-100 overflow-hidden">
                            <img src="<?php echo e($magazine->getCoverImageUrlOrDefault()); ?>" 
                                 alt="<?php echo e($magazine->title); ?>"
                                 class="w-full h-full object-cover">
                        </div>

                        <!-- Content -->
                        <div class="p-4">
                            <!-- Category Badge -->
                            <?php if($magazine->category): ?>
                                <div class="mb-2">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                        <?php echo e(ucfirst($magazine->category)); ?>

                                    </span>
                                </div>
                            <?php endif; ?>

                            <!-- Title -->
                            <h3 class="font-semibold text-gray-900 text-lg mb-2 line-clamp-2">
                                <?php echo e($magazine->title); ?>

                            </h3>

                            <!-- Description -->
                            <?php if($magazine->description): ?>
                                <p class="text-gray-600 text-sm mb-3 line-clamp-3">
                                    <?php echo e($magazine->description); ?>

                                </p>
                            <?php endif; ?>

                            <!-- Meta Info -->
                            <div class="flex items-center justify-between text-xs text-gray-500 mb-4">
                                <span><?php echo e($magazine->getFormattedFileSize()); ?></span>
                                <span><?php echo e($magazine->language_code ? strtoupper($magazine->language_code) : 'EN'); ?></span>
                            </div>

                            <!-- Actions -->
                            <div class="flex space-x-2">
                                <a href="<?php echo e(route('magazines.show', $magazine)); ?>" 
                                   class="flex-1 bg-purple-600 hover:bg-purple-700 text-white text-center px-3 py-2 rounded-lg text-sm font-medium transition-colors">
                                    View Details
                                </a>
                                <a href="<?php echo e(route('magazines.download', $magazine)); ?>" 
                                   class="flex-1 bg-green-600 hover:bg-green-700 text-white text-center px-3 py-2 rounded-lg text-sm font-medium transition-colors">
                                    Download
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Pagination -->
            <?php if($magazines->hasPages()): ?>
                <div class="mt-8">
                    <?php echo e($magazines->links()); ?>

                </div>
            <?php endif; ?>
        <?php else: ?>
            <!-- Empty State -->
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">No magazines found</h3>
                <p class="mt-1 text-sm text-gray-500">
                    <?php if(request('search') || request('category') || request('language_code')): ?>
                        Try adjusting your search criteria.
                    <?php else: ?>
                        No magazines are currently available.
                    <?php endif; ?>
                </p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.line-clamp-3 {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ash/Backup & Project/net_on_you/resources/views/magazines/index.blade.php ENDPATH**/ ?>