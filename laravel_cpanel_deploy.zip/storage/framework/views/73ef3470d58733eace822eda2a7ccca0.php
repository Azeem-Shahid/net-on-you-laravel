<?php $__env->startSection('title', 'Create Magazine'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.magazines.index')); ?>">Magazines</a></li>
                        <li class="breadcrumb-item active">Create Magazine</li>
                    </ol>
                </div>
                <h4 class="page-title">Create New Magazine</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card">
                <div class="card-body">
                    <form id="magazineForm" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label for="title" class="form-label">Title <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="title" name="title" required 
                                           placeholder="Enter magazine title">
                                    <div class="invalid-feedback" id="title-error"></div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="">Select Status</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                    <div class="invalid-feedback" id="status-error"></div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4" 
                                      placeholder="Enter magazine description (optional)"></textarea>
                            <div class="invalid-feedback" id="description-error"></div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="category" class="form-label">Category</label>
                                    <select class="form-select" id="category" name="category">
                                        <option value="">Select Category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category); ?>"><?php echo e(ucfirst($category)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value="new">+ Add New Category</option>
                                    </select>
                                    <div class="invalid-feedback" id="category-error"></div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="language_code" class="form-label">Language <span class="text-danger">*</span></label>
                                    <select class="form-select" id="language_code" name="language_code" required>
                                        <option value="">Select Language</option>
                                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($language); ?>"><?php echo e(strtoupper($language)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option value="new">+ Add New Language</option>
                                    </select>
                                    <div class="invalid-feedback" id="language_code-error"></div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="published_at" class="form-label">Published Date</label>
                                    <input type="date" class="form-control" id="published_at" name="published_at">
                                    <div class="invalid-feedback" id="published_at-error"></div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="magazine_file" class="form-label">Magazine File <span class="text-danger">*</span></label>
                                    <input type="file" class="form-control" id="magazine_file" name="magazine_file" 
                                           accept=".pdf" required>
                                    <div class="form-text">Only PDF files are allowed. Maximum size: 10MB</div>
                                    <div class="invalid-feedback" id="magazine_file-error"></div>
                                </div>
                            </div>
                        </div>

                        <!-- Cover Image Upload -->
                        <div class="mb-3">
                            <label for="cover_image" class="form-label">Cover Image</label>
                            <input type="file" class="form-control" id="cover_image" name="cover_image" 
                                   accept="image/*">
                            <div class="form-text">Upload a cover image for the magazine (optional). Supported formats: JPEG, PNG, GIF. Maximum size: 2MB</div>
                            <div class="invalid-feedback" id="cover_image-error"></div>
                        </div>

                        <!-- Cover Image Preview -->
                        <div class="mb-3" id="coverPreview" style="display: none;">
                            <label class="form-label">Cover Image Preview</label>
                            <div class="card border">
                                <div class="card-body">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm me-3">
                                            <img id="coverPreviewImg" src="" alt="Cover Preview" class="rounded" style="width: 60px; height: 80px; object-fit: cover;">
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1" id="coverFileName"></h6>
                                            <p class="mb-0 text-muted" id="coverFileSize"></p>
                                        </div>
                                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeCover()">
                                            <i class="mdi mdi-close"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- File Preview -->
                        <div class="mb-3" id="filePreview" style="display: none;">
                            <label class="form-label">File Preview</label>
                            <div class="card border">
                                <div class="card-body">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm me-3">
                                            <div class="avatar-title bg-light text-primary rounded">
                                                <i class="mdi mdi-file-pdf-box font-24"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1" id="fileName"></h6>
                                            <p class="mb-1 text-muted" id="fileSize"></p>
                                            <p class="mb-0 text-muted" id="fileType"></p>
                                        </div>
                                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeFile()">
                                            <i class="mdi mdi-close"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('admin.magazines.index')); ?>" class="btn btn-secondary">
                                <i class="mdi mdi-arrow-left"></i> Back to Magazines
                            </a>
                            <button type="submit" class="btn btn-primary" id="submitBtn">
                                <i class="mdi mdi-upload"></i> Upload Magazine
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Upload Progress Modal -->
<div class="modal fade" id="uploadProgressModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body text-center">
                <div class="mb-3">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Uploading...</span>
                    </div>
                </div>
                <h6>Uploading Magazine...</h6>
                <p class="text-muted mb-0">Please wait while we process your file.</p>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
let selectedFile = null;

// File selection handler
document.getElementById('magazine_file').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        // Validate file type
        if (file.type !== 'application/pdf') {
            alert('Please select a valid PDF file.');
            this.value = '';
            return;
        }

        // Validate file size (10MB = 10 * 1024 * 1024 bytes)
        if (file.size > 10 * 1024 * 1024) {
            alert('File size must be less than 10MB.');
            this.value = '';
            return;
        }

        selectedFile = file;
        showFilePreview(file);
    }
});

function showFilePreview(file) {
    const preview = document.getElementById('filePreview');
    const fileName = document.getElementById('fileName');
    const fileSize = document.getElementById('fileSize');
    const fileType = document.getElementById('fileType');

    fileName.textContent = file.name;
    fileSize.textContent = formatFileSize(file.size);
    fileType.textContent = file.type;

    preview.style.display = 'block';
}

function removeFile() {
    document.getElementById('magazine_file').value = '';
    document.getElementById('filePreview').style.display = 'none';
    selectedFile = null;
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Form submission
document.getElementById('magazineForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    if (!selectedFile) {
        alert('Please select a file to upload.');
        return;
    }

    // Show upload progress
    const progressModal = new bootstrap.Modal(document.getElementById('uploadProgressModal'));
    progressModal.show();

    // Disable submit button
    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="mdi mdi-loading mdi-spin"></i> Uploading...';

    // Create FormData
    const formData = new FormData(this);

    // Send request
    fetch('<?php echo e(route("admin.magazines.store")); ?>', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        progressModal.hide();
        
        if (data.success) {
            // Show success message
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: data.message,
                confirmButtonText: 'OK'
            }).then((result) => {
                // Redirect to magazines index
                window.location.href = '<?php echo e(route("admin.magazines.index")); ?>';
            });
        } else {
            // Show validation errors
            showValidationErrors(data.errors);
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="mdi mdi-upload"></i> Upload Magazine';
        }
    })
    .catch(error => {
        progressModal.hide();
        console.error('Error:', error);
        
        Swal.fire({
            icon: 'error',
            title: 'Upload Failed',
            text: 'An error occurred while uploading the magazine. Please try again.',
            confirmButtonText: 'OK'
        });
        
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="mdi mdi-upload"></i> Upload Magazine';
    });
});

function showValidationErrors(errors) {
    // Clear previous errors
    document.querySelectorAll('.is-invalid').forEach(element => {
        element.classList.remove('is-invalid');
    });
    document.querySelectorAll('.invalid-feedback').forEach(element => {
        element.textContent = '';
    });

    // Show new errors
    Object.keys(errors).forEach(field => {
        const input = document.querySelector(`[name="${field}"]`);
        const errorDiv = document.getElementById(`${field}-error`);
        
        if (input && errorDiv) {
            input.classList.add('is-invalid');
            errorDiv.textContent = errors[field][0];
        }
    });
}

// Auto-fill published date with current date
document.addEventListener('DOMContentLoaded', function() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('published_at').value = today;
    
    // Initialize category and language fields
    initializeCategoryField();
    initializeLanguageField();
});

// Category field functionality
function initializeCategoryField() {
    const categorySelect = document.getElementById('category');
    categorySelect.addEventListener('change', function() {
        if (this.value === 'new') {
            const newCategory = prompt('Enter new category name:');
            if (newCategory && newCategory.trim()) {
                // Add new option
                const option = new Option(newCategory.trim(), newCategory.trim());
                categorySelect.add(option, 1);
                categorySelect.value = newCategory.trim();
            } else {
                categorySelect.value = '';
            }
        }
    });
}

// Language field functionality
function initializeLanguageField() {
    const languageSelect = document.getElementById('language_code');
    languageSelect.addEventListener('change', function() {
        if (this.value === 'new') {
            const newLanguage = prompt('Enter new language code (e.g., fr, de, es):');
            if (newLanguage && newLanguage.trim()) {
                // Add new option
                const option = new Option(newLanguage.trim().toUpperCase(), newLanguage.trim().toLowerCase());
                languageSelect.add(option, 1);
                languageSelect.value = newLanguage.trim().toLowerCase();
            } else {
                languageSelect.value = '';
            }
        }
    });
}

// Cover image preview functionality
document.getElementById('cover_image').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('coverPreviewImg').src = e.target.result;
                document.getElementById('coverFileName').textContent = file.name;
                document.getElementById('coverFileSize').textContent = formatFileSize(file.size);
                document.getElementById('coverPreview').style.display = 'block';
            };
            reader.readAsDataURL(file);
        } else {
            alert('Please select a valid image file.');
            this.value = '';
        }
    }
});

function removeCover() {
    document.getElementById('cover_image').value = '';
    document.getElementById('coverPreview').style.display = 'none';
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ash/Backup & Project/net_on_you/resources/views/admin/magazines/create.blade.php ENDPATH**/ ?>