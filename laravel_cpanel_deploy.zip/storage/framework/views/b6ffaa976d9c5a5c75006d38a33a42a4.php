<?php
    $currentLanguage = current_language();
    $availableLanguages = available_languages();
?>

<div class="relative" x-data="{ open: false }">
    <!-- Language Button -->
    <button @click="open = !open" 
            @click.away="open = false"
            class="flex items-center space-x-2 px-3 py-2 text-sm font-medium text-white hover:text-action focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-action rounded-md transition-colors">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"></path>
        </svg>
        <span class="hidden sm:inline"><?php echo e($availableLanguages->firstWhere('code', $currentLanguage)->name ?? 'Language'); ?></span>
        <svg class="w-4 h-4 transition-transform" :class="{ 'rotate-180': open }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
        </svg>
    </button>

    <!-- Dropdown Menu -->
    <div x-show="open" 
         x-transition:enter="transition ease-out duration-100"
         x-transition:enter-start="transform opacity-0 scale-95"
         x-transition:enter-end="transform opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-75"
         x-transition:leave-start="transform opacity-100 scale-100"
         x-transition:leave-end="transform opacity-0 scale-95"
         class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 z-50">
        <div class="py-1">
            <?php $__currentLoopData = $availableLanguages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(route('language.switch')); ?>" method="POST" class="block">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="language" value="<?php echo e($language->code); ?>">
                    <input type="hidden" name="redirect" value="<?php echo e(request()->url()); ?>">
                    
                    <button type="submit" 
                            @click="open = false"
                            class="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900 flex items-center justify-between <?php echo e($language->code === $currentLanguage ? 'bg-gray-100 text-[#1d003f] font-medium' : ''); ?>">
                        <span class="flex items-center">
                            <?php if($language->code === $currentLanguage): ?>
                                <svg class="w-4 h-4 mr-2 text-[#00ff00]" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                            <?php endif; ?>
                            <?php echo e($language->name); ?>

                        </span>
                        <?php if($language->is_default): ?>
                            <span class="text-xs text-gray-500">Default</span>
                        <?php endif; ?>
                    </button>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH /media/ash/Backup & Project/net_on_you/resources/views/components/language-switcher.blade.php ENDPATH**/ ?>