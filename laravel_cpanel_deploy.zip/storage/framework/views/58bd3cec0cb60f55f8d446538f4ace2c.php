<?php $__env->startSection('title', 'Referral Management - Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="page-header">
        <div class="row align-items-center">
            <div class="col">
                <h3 class="page-title">Referral Management</h3>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Referrals</li>
                </ul>
            </div>
            <div class="col-auto">
                <a href="<?php echo e(route('admin.referrals.export')); ?>" class="btn btn-primary">
                    <i class="fas fa-download"></i> Export CSV
                </a>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row">
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0"><?php echo e($stats['total_referrals']); ?></h4>
                            <p class="text-muted mb-0">Total Referrals</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0"><?php echo e($stats['level_1_count']); ?></h4>
                            <p class="text-muted mb-0">Level 1</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0"><?php echo e($stats['level_2_count']); ?></h4>
                            <p class="text-muted mb-0">Level 2</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0"><?php echo e($stats['level_3_count']); ?></h4>
                            <p class="text-muted mb-0">Level 3</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0"><?php echo e($stats['level_4_count']); ?></h4>
                            <p class="text-muted mb-0">Level 4</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h4 class="mb-0"><?php echo e($stats['level_5_count'] + $stats['level_6_count']); ?></h4>
                            <p class="text-muted mb-0">Level 5-6</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.referrals.index')); ?>" class="row">
                <div class="col-md-2">
                    <label class="form-label">Level</label>
                    <select name="level" class="form-select">
                        <option value="">All Levels</option>
                        <?php for($i = 1; $i <= 6; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e(request('level') == $i ? 'selected' : ''); ?>>Level <?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Referrer ID</label>
                    <input type="number" name="referrer_id" class="form-control" value="<?php echo e(request('referrer_id')); ?>" placeholder="Referrer ID">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Referred User ID</label>
                    <input type="number" name="referred_user_id" class="form-control" value="<?php echo e(request('referred_user_id')); ?>" placeholder="Referred User ID">
                </div>
                <div class="col-md-2">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary d-block w-100">Filter</button>
                </div>
                <div class="col-md-2">
                    <label class="form-label">&nbsp;</label>
                    <a href="<?php echo e(route('admin.referrals.index')); ?>" class="btn btn-secondary d-block w-100">Clear</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Referrals Table -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Referrer</th>
                            <th>Referred User</th>
                            <th>Level</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($referral->id); ?></td>
                                <td>
                                    <div>
                                        <strong><?php echo e($referral->referrer->name); ?></strong>
                                        <br>
                                        <small class="text-muted">ID: <?php echo e($referral->referrer->id); ?></small>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <strong><?php echo e($referral->referredUser->name); ?></strong>
                                        <br>
                                        <small class="text-muted">ID: <?php echo e($referral->referredUser->id); ?></small>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-primary">Level <?php echo e($referral->level); ?></span>
                                </td>
                                <td><?php echo e($referral->created_at->format('M d, Y H:i')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.referrals.show', $referral->referrer)); ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i> View Tree
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">No referrals found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center">
                <?php echo e($referrals->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ash/Backup & Project/net_on_you/resources/views/admin/referrals/index.blade.php ENDPATH**/ ?>