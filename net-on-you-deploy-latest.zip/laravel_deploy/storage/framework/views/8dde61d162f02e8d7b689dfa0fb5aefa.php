<?php $__env->startSection('title', 'Dashboard - NetOnYou'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <!-- Welcome Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900"><?php echo e(t('welcome_back', [], 'dashboard')); ?>, <?php echo e($user->name); ?>!</h1>
            <p class="text-gray-600 mt-2"><?php echo e(t('manage_account_progress', [], 'dashboard')); ?></p>
        </div>

        <!-- Success Message -->
        <?php if(session('success')): ?>
            <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Profile Summary Card -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4"><?php echo e(t('profile_summary', [], 'dashboard')); ?></h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-600"><?php echo e(t('name', [], 'common')); ?></label>
                    <p class="text-gray-900 font-medium"><?php echo e($user->name); ?></p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-600"><?php echo e(t('email', [], 'common')); ?></label>
                    <p class="text-gray-900 font-medium"><?php echo e($user->email); ?></p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-600"><?php echo e(t('language', [], 'common')); ?></label>
                    <p class="text-gray-900 font-medium"><?php echo e(strtoupper($user->language)); ?></p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-600"><?php echo e(t('wallet_address', [], 'dashboard')); ?></label>
                    <p class="text-gray-900 font-medium break-all"><?php echo e($user->wallet_address ?: t('not_set', [], 'common')); ?></p>
                </div>
            </div>
        </div>

        <!-- Subscription Status Card -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4"><?php echo e(t('subscription_status', [], 'dashboard')); ?></h2>
            <div class="flex items-center justify-between">
                <div>
                    <?php
                        $status = $user->getSubscriptionStatus();
                        $statusColor = $status === 'active' ? 'text-[#00ff00]' : ($status === 'grace' ? 'text-yellow-600' : 'text-[#ff0000]');
                        $statusText = ucfirst($status);
                    ?>
                    <span class="text-2xl font-bold <?php echo e($statusColor); ?>"><?php echo e($statusText); ?></span>
                    <?php if($user->subscription_end_date): ?>
                        <p class="text-gray-600 mt-1">
                            <?php echo e(t('expires', [], 'dashboard')); ?>: <?php echo e($user->subscription_end_date->format('M d, Y')); ?>

                        </p>
                    <?php endif; ?>
                </div>
                <div class="text-right">
                    <?php if($user->subscription_start_date): ?>
                        <p class="text-gray-600"><?php echo e(t('started', [], 'dashboard')); ?>: <?php echo e($user->subscription_start_date->format('M d, Y')); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Referral Overview Card -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Referral Overview</h2>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-600 mb-2">Your Referral Link</label>
                <div class="flex">
                    <input type="text" value="<?php echo e($user->getReferralLink()); ?>" readonly 
                           class="flex-1 border border-gray-300 rounded-l-lg px-3 py-2 bg-gray-50 text-gray-600">
                    <button onclick="copyToClipboard('<?php echo e($user->getReferralLink()); ?>')" 
                            class="bg-[#1d003f] text-white px-4 py-2 rounded-r-lg hover:bg-[#2a0057] transition-colors">
                        Copy
                    </button>
                </div>
            </div>
            <div class="grid grid-cols-2 md:grid-cols-6 gap-4">
                <?php for($level = 1; $level <= 6; $level++): ?>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-[#1d003f]"><?php echo e($referralStats[$level] ?? 0); ?></div>
                        <div class="text-sm text-gray-600">Level <?php echo e($level); ?></div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>

        <!-- Commission Earnings Card -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Commission Earnings</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="text-center p-4 bg-green-50 rounded-lg">
                    <div class="text-3xl font-bold text-[#00ff00]">$<?php echo e(number_format($commissionEarnings['monthly'], 2)); ?></div>
                    <div class="text-gray-600">This Month</div>
                </div>
                <div class="text-center p-4 bg-blue-50 rounded-lg">
                    <div class="text-3xl font-bold text-[#1d003f]">$<?php echo e(number_format($commissionEarnings['total'], 2)); ?></div>
                    <div class="text-gray-600">Total Earnings</div>
                </div>
                <div class="text-center p-4 bg-yellow-50 rounded-lg">
                    <div class="text-3xl font-bold text-yellow-600">$<?php echo e(number_format($commissionEarnings['pending'], 2)); ?></div>
                    <div class="text-gray-600">Pending Payout</div>
                </div>
                <div class="text-center p-4 bg-purple-50 rounded-lg">
                    <div class="text-3xl font-bold text-purple-600"><?php echo e($commissionBreakdown['month']); ?></div>
                    <div class="text-gray-600">Current Period</div>
                </div>
            </div>
            
            <!-- Commission Breakdown -->
            <div class="mt-6 p-4 bg-gray-50 rounded-lg">
                <h3 class="text-lg font-medium text-gray-800 mb-3">This Month's Breakdown</h3>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div>
                        <div class="text-2xl font-bold text-[#00ff00]">$<?php echo e(number_format($commissionBreakdown['eligible'], 2)); ?></div>
                        <div class="text-sm text-gray-600">Eligible</div>
                    </div>
                    <div>
                        <div class="text-2xl font-bold text-red-600">$<?php echo e(number_format($commissionBreakdown['ineligible'], 2)); ?></div>
                        <div class="text-sm text-gray-600">Ineligible</div>
                    </div>
                    <div>
                        <div class="text-2xl font-bold text-yellow-600">$<?php echo e(number_format($commissionBreakdown['pending'], 2)); ?></div>
                        <div class="text-sm text-gray-600">Pending</div>
                    </div>
                    <div>
                        <div class="text-2xl font-bold text-blue-600">$<?php echo e(number_format($commissionBreakdown['paid'], 2)); ?></div>
                        <div class="text-sm text-gray-600">Paid</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Transactions Card -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Recent Transactions</h2>
            <?php if($recentTransactions->count() > 0): ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Currency</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Gateway</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo e($transaction->created_at->format('M d, Y')); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo e(number_format($transaction->amount, 2)); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo e($transaction->currency); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo e($transaction->gateway); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php
                                            $statusColor = $transaction->status === 'completed' ? 'text-[#00ff00]' : 
                                                          ($transaction->status === 'pending' ? 'text-yellow-600' : 'text-[#ff0000]');
                                        ?>
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($statusColor); ?>">
                                            <?php echo e(ucfirst($transaction->status)); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-gray-500 text-center py-4">No transactions found.</p>
            <?php endif; ?>
        </div>

        <!-- Magazine Access Card -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Magazine Access</h2>
            <?php if($magazineEntitlements->count() > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <?php $__currentLoopData = $magazineEntitlements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entitlement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h3 class="font-medium text-gray-900"><?php echo e($entitlement->magazine->title ?? 'Magazine #' . $entitlement->magazine_id); ?></h3>
                                    <p class="text-sm text-gray-600"><?php echo e($entitlement->granted_at->format('M d, Y')); ?></p>
                                    <p class="text-xs text-gray-500"><?php echo e(ucfirst($entitlement->reason)); ?></p>
                                </div>
                                <a href="#" class="bg-[#1d003f] text-white px-3 py-2 rounded-lg text-sm hover:bg-[#2a0057] transition-colors">
                                    Download
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="text-gray-500 text-center py-4">No magazine access available.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        // Show success message
        const button = event.target;
        const originalText = button.textContent;
        button.textContent = 'Copied!';
        button.classList.add('bg-green-600');
        
        setTimeout(() => {
            button.textContent = originalText;
            button.classList.remove('bg-green-600');
        }, 2000);
    });
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ash/Backup & Project/net_on_you/resources/views/dashboard.blade.php ENDPATH**/ ?>