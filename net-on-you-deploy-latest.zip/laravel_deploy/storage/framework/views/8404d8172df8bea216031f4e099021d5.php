<?php $__env->startSection('title', 'Edit Profile - NetOnYou'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50">
    <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <!-- Page Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900">Edit Profile</h1>
            <p class="text-gray-600 mt-2">Update your personal information</p>
        </div>

        <!-- Profile Edit Form -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-6">Profile Information</h2>

            <?php if($errors->any()): ?>
                <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg">
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('profile.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Name -->
                    <div class="md:col-span-2">
                        <label for="name" class="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                        <input type="text" id="name" name="name" value="<?php echo e(old('name', $user->name)); ?>" required
                               class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#1d003f] focus:border-transparent">
                    </div>

                    <!-- Email (Read-only) -->
                    <div class="md:col-span-2">
                        <label for="email" class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                        <input type="email" id="email" value="<?php echo e($user->email); ?>" disabled
                               class="w-full border border-gray-300 rounded-lg px-3 py-2 bg-gray-50 text-gray-500 cursor-not-allowed">
                        <p class="text-sm text-gray-500 mt-1">Email address cannot be changed</p>
                    </div>

                    <!-- Language -->
                    <div>
                        <label for="language" class="block text-sm font-medium text-gray-700 mb-2">Language</label>
                        <select id="language" name="language" required
                                class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#1d003f] focus:border-transparent">
                            <option value="en" <?php echo e(old('language', $user->language) === 'en' ? 'selected' : ''); ?>>English</option>
                            <option value="es" <?php echo e(old('language', $user->language) === 'es' ? 'selected' : ''); ?>>Español</option>
                            <option value="fr" <?php echo e(old('language', $user->language) === 'fr' ? 'selected' : ''); ?>>Français</option>
                            <option value="de" <?php echo e(old('language', $user->language) === 'de' ? 'selected' : ''); ?>>Deutsch</option>
                            <option value="it" <?php echo e(old('language', $user->language) === 'it' ? 'selected' : ''); ?>>Italiano</option>
                        </select>
                    </div>

                    <!-- Wallet Address -->
                    <div>
                        <label for="wallet_address" class="block text-sm font-medium text-gray-700 mb-2">Wallet Address</label>
                        <input type="text" id="wallet_address" name="wallet_address" value="<?php echo e(old('wallet_address', $user->wallet_address)); ?>"
                               placeholder="0x..."
                               class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#1d003f] focus:border-transparent">
                        <p class="text-sm text-gray-500 mt-1">Optional - Your cryptocurrency wallet address</p>
                    </div>
                </div>

                <div class="flex justify-end space-x-4 mt-8">
                    <a href="<?php echo e(route('dashboard')); ?>" class="bg-gray-300 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-400 transition-colors">
                        Cancel
                    </a>
                    <button type="submit" class="bg-[#1d003f] text-white px-6 py-2 rounded-lg font-medium hover:bg-[#2a0057] transition-colors">
                        Update Profile
                    </button>
                </div>
            </form>
        </div>

        <!-- Change Password Section -->
        <div class="bg-white rounded-lg shadow-md p-6 mt-6">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-semibold text-gray-800">Password</h2>
                <a href="<?php echo e(route('profile.change-password')); ?>" class="bg-[#1d003f] text-white px-4 py-2 rounded-lg font-medium hover:bg-[#2a0057] transition-colors">
                    Change Password
                </a>
            </div>
            <p class="text-gray-600">Keep your account secure by using a strong password and updating it regularly.</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/ash/Backup & Project/net_on_you/resources/views/profile/edit.blade.php ENDPATH**/ ?>