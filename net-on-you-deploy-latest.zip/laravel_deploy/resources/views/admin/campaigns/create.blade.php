@extends('admin.layouts.app')

@section('title', 'Create Email Campaign')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3 mb-0">Create Email Campaign</h1>
                <a href="{{ route('admin.campaigns.index') }}" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Campaigns
                </a>
            </div>

            <div class="row">
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Campaign Details</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="{{ route('admin.campaigns.store') }}" id="campaignForm">
                                @csrf
                                
                                <div class="mb-3">
                                    <label for="template_id" class="form-label">Email Template <span class="text-danger">*</span></label>
                                    <select class="form-select @error('template_id') is-invalid @enderror" 
                                            id="template_id" name="template_id" required>
                                        <option value="">Select Template</option>
                                        @foreach($templates as $template)
                                            <option value="{{ $template->id }}" 
                                                    data-variables="{{ json_encode($template->variables) }}">
                                                {{ $template->name }} ({{ strtoupper($template->language) }})
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('template_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="subject" class="form-label">Campaign Subject <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control @error('subject') is-invalid @enderror" 
                                           id="subject" name="subject" value="{{ old('subject') }}" 
                                           placeholder="Enter campaign subject..." required>
                                    @error('subject')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Recipient Selection <span class="text-danger">*</span></label>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="recipient_type" 
                                               id="all_users" value="all_users" 
                                               {{ old('recipient_type') == 'all_users' ? 'checked' : '' }} required>
                                        <label class="form-check-label" for="all_users">
                                            <strong>All Users</strong> ({{ $userCount }} users)
                                        </label>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="recipient_type" 
                                               id="marketing_opt_in" value="marketing_opt_in" 
                                               {{ old('recipient_type') == 'marketing_opt_in' ? 'checked' : '' }}>
                                        <label class="form-check-label" for="marketing_opt_in">
                                            <strong>Marketing Opt-in Only</strong> ({{ $marketingOptInCount }} users)
                                        </label>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="recipient_type" 
                                               id="custom_selection" value="custom_selection" 
                                               {{ old('recipient_type') == 'custom_selection' ? 'checked' : '' }}>
                                        <label class="form-check-label" for="custom_selection">
                                            <strong>Custom Selection</strong>
                                        </label>
                                    </div>
                                    @error('recipient_type')
                                        <div class="invalid-feedback d-block">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Custom User Selection (initially hidden) -->
                                <div id="customUserSelection" class="mb-3" style="display: none;">
                                    <label class="form-label">Select Users</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="userSearch" 
                                               placeholder="Search users by name or email...">
                                        <button class="btn btn-outline-secondary" type="button" onclick="searchUsers()">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                    <div id="userSearchResults" class="mt-2"></div>
                                    <div id="selectedUsers" class="mt-2"></div>
                                </div>

                                <div class="mb-3">
                                    <label for="test_email" class="form-label">Test Email (Optional)</label>
                                    <div class="input-group">
                                        <input type="email" class="form-control" id="test_email" name="test_email" 
                                               placeholder="admin@example.com">
                                        <button type="button" class="btn btn-outline-info" onclick="sendTestEmail()">
                                            <i class="fas fa-paper-plane"></i> Send Test
                                        </button>
                                    </div>
                                    <div class="form-text">Send a test email to preview your campaign</div>
                                </div>

                                <div class="d-flex justify-content-end gap-2">
                                    <a href="{{ route('admin.campaigns.index') }}" class="btn btn-secondary">
                                        Cancel
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-paper-plane"></i> Send Campaign
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <!-- Campaign Preview -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Campaign Preview</h5>
                        </div>
                        <div class="card-body">
                            <div id="campaignPreview">
                                <p class="text-muted text-center">Select a template to see preview</p>
                            </div>
                        </div>
                    </div>

                    <!-- Recipient Count -->
                    <div class="card mt-3">
                        <div class="card-header">
                            <h5 class="mb-0">Recipient Count</h5>
                        </div>
                        <div class="card-body">
                            <div id="recipientCount">
                                <p class="text-muted text-center">Select recipient type to see count</p>
                            </div>
                        </div>
                    </div>

                    <!-- Template Variables -->
                    <div class="card mt-3">
                        <div class="card-header">
                            <h5 class="mb-0">Template Variables</h5>
                        </div>
                        <div class="card-body">
                            <div id="templateVariables">
                                <p class="text-muted text-center">Select a template to see variables</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
let selectedUsers = [];

document.addEventListener('DOMContentLoaded', function() {
    // Handle recipient type change
    document.querySelectorAll('input[name="recipient_type"]').forEach(radio => {
        radio.addEventListener('change', function() {
            updateRecipientCount();
            if (this.value === 'custom_selection') {
                document.getElementById('customUserSelection').style.display = 'block';
            } else {
                document.getElementById('customUserSelection').style.display = 'none';
                selectedUsers = [];
                updateSelectedUsersDisplay();
            }
        });
    });

    // Handle template change
    document.getElementById('template_id').addEventListener('change', function() {
        updateCampaignPreview();
        updateTemplateVariables();
    });

    // Initial updates
    updateRecipientCount();
});

function updateRecipientCount() {
    const recipientType = document.querySelector('input[name="recipient_type"]:checked')?.value;
    if (!recipientType) {
        document.getElementById('recipientCount').innerHTML = '<p class="text-muted text-center">Select recipient type to see count</p>';
        return;
    }

    const formData = new FormData();
    formData.append('recipient_type', recipientType);
    
    if (recipientType === 'custom_selection') {
        formData.append('custom_user_ids', JSON.stringify(selectedUsers));
    }

    fetch('{{ route("admin.campaigns.recipient-count") }}', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('recipientCount').innerHTML = `
            <div class="text-center">
                <h3 class="text-primary">${data.count}</h3>
                <p class="mb-0">recipients will receive this campaign</p>
            </div>
        `;
    })
    .catch(error => {
        console.error('Error getting recipient count:', error);
        document.getElementById('recipientCount').innerHTML = '<p class="text-danger">Error loading recipient count</p>';
    });
}

function updateCampaignPreview() {
    const templateSelect = document.getElementById('template_id');
    const selectedOption = templateSelect.options[templateSelect.selectedIndex];
    
    if (!selectedOption.value) {
        document.getElementById('campaignPreview').innerHTML = '<p class="text-muted text-center">Select a template to see preview</p>';
        return;
    }

    const formData = new FormData();
    formData.append('template_id', selectedOption.value);
    formData.append('subject', document.getElementById('subject').value || 'Sample Subject');

    fetch('{{ route("admin.campaigns.preview") }}', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('campaignPreview').innerHTML = `
            <div class="mb-3">
                <strong>Subject:</strong>
                <p class="mb-2">${data.subject}</p>
            </div>
            <div>
                <strong>Body Preview:</strong>
                <div class="bg-light p-2 rounded" style="max-height: 200px; overflow-y: auto;">
                    ${data.body.replace(/\n/g, '<br>')}
                </div>
            </div>
        `;
    })
    .catch(error => {
        console.error('Error getting preview:', error);
        document.getElementById('campaignPreview').innerHTML = '<p class="text-danger">Error loading preview</p>';
    });
}

function updateTemplateVariables() {
    const templateSelect = document.getElementById('template_id');
    const selectedOption = templateSelect.options[templateSelect.selectedIndex];
    
    if (!selectedOption.value) {
        document.getElementById('templateVariables').innerHTML = '<p class="text-muted text-center">Select a template to see variables</p>';
        return;
    }

    const variables = JSON.parse(selectedOption.dataset.variables || '[]');
    
    if (variables.length === 0) {
        document.getElementById('templateVariables').innerHTML = '<p class="text-muted">No variables defined</p>';
        return;
    }

    let variablesHtml = '<div class="row">';
    variables.forEach(variable => {
        variablesHtml += `
            <div class="col-6 mb-2">
                <code class="bg-light px-2 py-1 rounded">{${variable}}</code>
            </div>
        `;
    });
    variablesHtml += '</div>';
    
    document.getElementById('templateVariables').innerHTML = variablesHtml;
}

function searchUsers() {
    const searchTerm = document.getElementById('userSearch').value;
    if (!searchTerm) return;

    // This would typically make an AJAX call to search users
    // For now, we'll show a placeholder
    document.getElementById('userSearchResults').innerHTML = `
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i> User search functionality would be implemented here.
            <br>Searching for: "${searchTerm}"
        </div>
    `;
}

function addUser(userId, userName) {
    if (!selectedUsers.includes(userId)) {
        selectedUsers.push(userId);
        updateSelectedUsersDisplay();
        updateRecipientCount();
    }
}

function removeUser(userId) {
    selectedUsers = selectedUsers.filter(id => id !== userId);
    updateSelectedUsersDisplay();
    updateRecipientCount();
}

function updateSelectedUsersDisplay() {
    const container = document.getElementById('selectedUsers');
    if (selectedUsers.length === 0) {
        container.innerHTML = '<p class="text-muted">No users selected</p>';
        return;
    }

    let html = '<div class="mb-2"><strong>Selected Users:</strong></div>';
    selectedUsers.forEach(userId => {
        html += `
            <div class="d-flex justify-content-between align-items-center mb-1">
                <span>User ID: ${userId}</span>
                <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeUser(${userId})">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
    });
    container.innerHTML = html;
}

function sendTestEmail() {
    const testEmail = document.getElementById('test_email').value;
    const templateId = document.getElementById('template_id').value;
    
    if (!testEmail || !templateId) {
        alert('Please enter a test email and select a template first.');
        return;
    }

    // This would typically make an AJAX call to send test email
    alert(`Test email would be sent to ${testEmail} using template ID ${templateId}`);
}

// Update preview when subject changes
document.getElementById('subject').addEventListener('input', function() {
    if (document.getElementById('template_id').value) {
        updateCampaignPreview();
    }
});
</script>
@endpush
