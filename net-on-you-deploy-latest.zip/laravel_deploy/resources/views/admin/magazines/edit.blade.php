@extends('admin.layouts.app')

@section('title', 'Edit Magazine')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.magazines.index') }}">Magazines</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.magazines.show', $magazine) }}">{{ $magazine->title }}</a></li>
                        <li class="breadcrumb-item active">Edit Magazine</li>
                    </ol>
                </div>
                <h4 class="page-title">Edit Magazine: {{ $magazine->title }}</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card">
                <div class="card-body">
                    <form id="magazineEditForm">
                        @csrf
                        @method('PUT')

                        <div class="row">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label for="title" class="form-label">Title <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="title" name="title" 
                                           value="{{ old('title', $magazine->title) }}" required>
                                    <div class="invalid-feedback" id="title-error"></div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="">Select Status</option>
                                        <option value="active" {{ old('status', $magazine->status) === 'active' ? 'selected' : '' }}>
                                            Active
                                        </option>
                                        <option value="inactive" {{ old('status', $magazine->status) === 'inactive' ? 'selected' : '' }}>
                                            Inactive
                                        </option>
                                        <option value="archived" {{ old('status', $magazine->status) === 'archived' ? 'selected' : '' }}>
                                            Archived
                                        </option>
                                    </select>
                                    <div class="invalid-feedback" id="status-error"></div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4">{{ old('description', $magazine->description) }}</textarea>
                            <div class="invalid-feedback" id="description-error"></div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="published_at" class="form-label">Published Date</label>
                                    <input type="date" class="form-control" id="published_at" name="published_at" 
                                           value="{{ old('published_at', $magazine->published_at ? $magazine->published_at->format('Y-m-d') : '') }}">
                                    <div class="invalid-feedback" id="published_at-error"></div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Current File</label>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm me-3">
                                            <div class="avatar-title bg-light text-primary rounded">
                                                <i class="mdi mdi-file-pdf-box font-24"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1">{{ $magazine->file_name }}</h6>
                                            <p class="mb-1 text-muted">{{ formatBytes($magazine->file_size) }}</p>
                                            <p class="mb-0 text-muted">{{ $magazine->mime_type }}</p>
                                        </div>
                                        <a href="{{ route('admin.magazines.download', $magazine) }}" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="mdi mdi-download"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Upload Information</label>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm me-3">
                                            <div class="avatar-title bg-light text-info rounded">
                                                <i class="mdi mdi-account font-24"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1">Uploaded By</h6>
                                            <p class="mb-1 text-muted">{{ $magazine->admin->name ?? 'Unknown' }}</p>
                                            <p class="mb-0 text-muted">{{ $magazine->created_at->format('M d, Y H:i') }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Access Statistics</label>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm me-3">
                                            <div class="avatar-title bg-light text-success rounded">
                                                <i class="mdi mdi-account-group font-24"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1">Total Access</h6>
                                            <p class="mb-1 text-muted">{{ $magazine->entitlements->count() }} users</p>
                                            <p class="mb-0 text-muted">{{ $magazine->entitlements->where('expires_at', '>', now())->count() }} active</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between">
                            <a href="{{ route('admin.magazines.show', $magazine) }}" class="btn btn-secondary">
                                <i class="mdi mdi-arrow-left"></i> Back to Magazine
                            </a>
                            <button type="submit" class="btn btn-primary" id="submitBtn">
                                <i class="mdi mdi-content-save"></i> Update Magazine
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Update Progress Modal -->
<div class="modal fade" id="updateProgressModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body text-center">
                <div class="mb-3">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Updating...</span>
                    </div>
                </div>
                <h6>Updating Magazine...</h6>
                <p class="text-muted mb-0">Please wait while we save your changes.</p>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
// Form submission
document.getElementById('magazineEditForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Show update progress
    const progressModal = new bootstrap.Modal(document.getElementById('updateProgressModal'));
    progressModal.show();

    // Disable submit button
    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="mdi mdi-loading mdi-spin"></i> Updating...';

    // Create FormData
    const formData = new FormData(this);

    // Send request
    fetch('{{ route("admin.magazines.update", $magazine) }}', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        progressModal.hide();
        
        if (data.success) {
            // Show success message
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: data.message,
                confirmButtonText: 'OK'
            }).then((result) => {
                // Redirect to magazine show page
                window.location.href = '{{ route("admin.magazines.show", $magazine) }}';
            });
        } else {
            // Show validation errors
            showValidationErrors(data.errors);
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="mdi mdi-content-save"></i> Update Magazine';
        }
    })
    .catch(error => {
        progressModal.hide();
        console.error('Error:', error);
        
        Swal.fire({
            icon: 'error',
            title: 'Update Failed',
            text: 'An error occurred while updating the magazine. Please try again.',
            confirmButtonText: 'OK'
        });
        
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="mdi mdi-content-save"></i> Update Magazine';
    });
});

function showValidationErrors(errors) {
    // Clear previous errors
    document.querySelectorAll('.is-invalid').forEach(element => {
        element.classList.remove('is-invalid');
    });
    document.querySelectorAll('.invalid-feedback').forEach(element => {
        element.textContent = '';
    });

    // Show new errors
    Object.keys(errors).forEach(field => {
        const input = document.querySelector(`[name="${field}"]`);
        const errorDiv = document.getElementById(`${field}-error`);
        
        if (input && errorDiv) {
            input.classList.add('is-invalid');
            errorDiv.textContent = errors[field][0];
        }
    });
}

// Auto-fill published date if empty
document.addEventListener('DOMContentLoaded', function() {
    const publishedAtInput = document.getElementById('published_at');
    if (!publishedAtInput.value) {
        const today = new Date().toISOString().split('T')[0];
        publishedAtInput.value = today;
    }
});
</script>
@endpush

@php
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, $precision) . ' ' . $units[$i];
}
@endphp
