@extends('admin.layouts.app')

@section('title', 'Email Templates')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3 mb-0">Email Templates</h1>
                <a href="{{ route('admin.email-templates.create') }}" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Create Template
                </a>
            </div>

            <!-- Filters -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" action="{{ route('admin.email-templates.index') }}" class="row g-3">
                        <div class="col-md-3 col-sm-6">
                            <label for="name" class="form-label">Template Name</label>
                            <input type="text" class="form-control" id="name" name="name" 
                                   value="{{ request('name') }}" placeholder="Search templates...">
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <label for="language" class="form-label">Language</label>
                            <select class="form-select" id="language" name="language">
                                <option value="">All Languages</option>
                                @foreach($languages as $lang)
                                    <option value="{{ $lang }}" {{ request('language') == $lang ? 'selected' : '' }}>
                                        {{ strtoupper($lang) }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3 col-sm-6 d-flex align-items-end">
                            <button type="submit" class="btn btn-secondary me-2">
                                <i class="fas fa-search"></i> Filter
                            </button>
                            <a href="{{ route('admin.email-templates.index') }}" class="btn btn-outline-secondary">
                                <i class="fas fa-times"></i> Clear
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Templates List -->
            <div class="row">
                @forelse($templates as $template)
                    <div class="col-lg-6 col-xl-4 mb-4">
                        <div class="card h-100">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="card-title mb-0">{{ $template->name }}</h5>
                                <span class="badge bg-primary">{{ strtoupper($template->language) }}</span>
                            </div>
                            <div class="card-body">
                                <h6 class="card-subtitle mb-2 text-muted">{{ $template->subject }}</h6>
                                <p class="card-text text-truncate">{{ Str::limit($template->body, 100) }}</p>
                                
                                @if(!empty($template->variables))
                                    <div class="mb-3">
                                        <small class="text-muted">
                                            <strong>Variables:</strong> {{ $template->variables_list }}
                                        </small>
                                    </div>
                                @endif
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        Updated: {{ $template->updated_at->diffForHumans() }}
                                    </small>
                                    <div class="btn-group" role="group">
                                        <a href="{{ route('admin.email-templates.show', $template) }}" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="{{ route('admin.email-templates.edit', $template) }}" 
                                           class="btn btn-sm btn-outline-secondary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-outline-info" 
                                                onclick="duplicateTemplate({{ $template->id }})">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-outline-danger" 
                                                onclick="deleteTemplate({{ $template->id }})">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="col-12">
                        <div class="text-center py-5">
                            <i class="fas fa-envelope fa-3x text-muted mb-3"></i>
                            <h4>No Email Templates Found</h4>
                            <p class="text-muted">Create your first email template to get started.</p>
                            <a href="{{ route('admin.email-templates.create') }}" class="btn btn-primary">
                                <i class="fas fa-plus"></i> Create Template
                            </a>
                        </div>
                    </div>
                @endforelse
            </div>

            <!-- Pagination -->
            @if($templates->hasPages())
                <div class="d-flex justify-content-center mt-4">
                    {{ $templates->links() }}
                </div>
            @endif
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Delete Template</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this email template? This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="deleteForm" method="POST" style="display: inline;">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Duplicate Confirmation Modal -->
<div class="modal fade" id="duplicateModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Duplicate Template</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to duplicate this email template?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="duplicateForm" method="POST" style="display: inline;">
                    @csrf
                    <button type="submit" class="btn btn-info">Duplicate</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function deleteTemplate(templateId) {
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    const form = document.getElementById('deleteForm');
    form.action = `/admin/email-templates/${templateId}`;
    modal.show();
}

function duplicateTemplate(templateId) {
    const modal = new bootstrap.Modal(document.getElementById('duplicateModal'));
    const form = document.getElementById('duplicateForm');
    form.action = `/admin/email-templates/${templateId}/duplicate`;
    modal.show();
}
</script>
@endpush
