@extends('admin.layouts.app')

@section('title', 'Create Email Template')

@php
function getLanguageDisplayName($code) {
    $names = [
        'en' => 'English',
        'ur' => 'Urdu',
        'fr' => 'French',
        'es' => 'Spanish',
        'ar' => 'Arabic',
        'hi' => 'Hindi',
        'bn' => 'Bengali',
        'pt' => 'Portuguese',
        'ru' => 'Russian',
        'zh' => 'Chinese'
    ];
    return $names[$code] ?? strtoupper($code);
}
@endphp

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3 mb-0">Create Email Template</h1>
                <a href="{{ route('admin.email-templates.index') }}" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Templates
                </a>
            </div>

            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ route('admin.email-templates.store') }}">
                        @csrf
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Template Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                           id="name" name="name" value="{{ old('name') }}" 
                                           placeholder="e.g., welcome_email, password_reset" required>
                                    <div class="form-text">Unique identifier for this template</div>
                                    @error('name')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="language" class="form-label">Language <span class="text-danger">*</span></label>
                                    <select class="form-select @error('language') is-invalid @enderror" 
                                            id="language" name="language" required>
                                        <option value="">Select Language</option>
                                        @foreach($languages as $lang)
                                            <option value="{{ $lang }}" {{ old('language') == $lang ? 'selected' : '' }}>
                                                {{ strtoupper($lang) }} - {{ $this->getLanguageDisplayName($lang) }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('language')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="subject" class="form-label">Email Subject <span class="text-danger">*</span></label>
                            <input type="text" class="form-control @error('subject') is-invalid @enderror" 
                                   id="subject" name="subject" value="{{ old('subject') }}" 
                                   placeholder="Welcome to Net On You!" required>
                            @error('subject')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="body" class="form-label">Email Body <span class="text-danger">*</span></label>
                            <textarea class="form-control @error('body') is-invalid @enderror" 
                                      id="body" name="body" rows="12" 
                                      placeholder="Write your email content here..." required>{{ old('body') }}</textarea>
                            <div class="form-text">
                                You can use HTML tags and variables like {name}, {email}, etc.
                            </div>
                            @error('body')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Template Variables</label>
                            <div class="row">
                                @foreach($commonVariables as $variable)
                                    <div class="col-md-3 col-sm-6 mb-2">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" 
                                                   name="variables[]" value="{{ $variable }}" 
                                                   id="var_{{ $variable }}"
                                                   {{ in_array($variable, old('variables', [])) ? 'checked' : '' }}>
                                            <label class="form-check-label" for="var_{{ $variable }}">
                                                <code>{ {{ $variable }} }</code>
                                            </label>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                            <div class="form-text">
                                Select the variables that this template will use. You can also add custom variables by typing them in the body as {variable_name}.
                            </div>
                        </div>

                        <div class="d-flex justify-content-end gap-2">
                            <a href="{{ route('admin.email-templates.index') }}" class="btn btn-secondary">
                                Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Create Template
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Template Examples -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="mb-0">Template Examples</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Welcome Email</h6>
                            <pre class="bg-light p-3 rounded"><code>Subject: Welcome {name}!

Hello {name},

Welcome to Net On You! Your account has been successfully created.

Plan: {plan}
Expires: {expiry}

Best regards,
The Net On You Team</code></pre>
                        </div>
                        <div class="col-md-6">
                            <h6>Password Reset</h6>
                            <pre class="bg-light p-3 rounded"><code>Subject: Password Reset Request

Hello {name},

You requested a password reset. Click the link below:

{reset_link}

If you didn't request this, please ignore this email.

Best regards,
The Net On You Team</code></pre>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
// Auto-detect variables from body content
document.getElementById('body').addEventListener('input', function() {
    const body = this.value;
    const variables = body.match(/\{([^}]+)\}/g);
    
    if (variables) {
        // Uncheck all variables first
        document.querySelectorAll('input[name="variables[]"]').forEach(checkbox => {
            checkbox.checked = false;
        });
        
        // Check detected variables
        variables.forEach(variable => {
            const varName = variable.replace(/[{}]/g, '');
            const checkbox = document.getElementById('var_' + varName);
            if (checkbox) {
                checkbox.checked = true;
            }
        });
    }
});
</script>
@endpush
