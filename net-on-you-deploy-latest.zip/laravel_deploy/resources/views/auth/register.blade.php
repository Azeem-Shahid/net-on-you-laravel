@extends('layouts.app')

@section('title', 'Register')

@section('content')
<div class="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8">
        <div class="text-center">
            <h2 class="text-3xl font-bold text-action">
                Create Account
            </h2>
            <p class="mt-2 text-sm text-white/80">
                Join our platform and start your journey
            </p>
        </div>

        <form class="mt-8 space-y-6" method="POST" action="{{ route('register') }}">
            @csrf
            
            <div class="space-y-4">
                <!-- Name -->
                <div>
                    <label for="name" class="block text-sm font-medium text-white">
                        Full Name
                    </label>
                    <input id="name" name="name" type="text" required 
                           class="mt-1 block w-full px-3 py-3 border border-action/30 rounded-lg bg-primary/50 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-action focus:border-transparent transition-all"
                           placeholder="Enter your full name"
                           value="{{ old('name') }}">
                </div>

                <!-- Email -->
                <div>
                    <label for="email" class="block text-sm font-medium text-white">
                        Email Address
                    </label>
                    <input id="email" name="email" type="email" required 
                           class="mt-1 block w-full px-3 py-3 border border-action/30 rounded-lg bg-primary/50 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-action focus:border-transparent transition-all"
                           placeholder="Enter your email address"
                           value="{{ old('email') }}">
                </div>

                <!-- Password -->
                <div>
                    <label for="password" class="block text-sm font-medium text-white">
                        Password
                    </label>
                    <input id="password" name="password" type="password" required 
                           class="mt-1 block w-full px-3 py-3 border border-action/30 rounded-lg bg-primary/50 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-action focus:border-transparent transition-all"
                           placeholder="Create a strong password">
                </div>

                <!-- Confirm Password -->
                <div>
                    <label for="password_confirmation" class="block text-sm font-medium text-white">
                        Confirm Password
                    </label>
                    <input id="password_confirmation" name="password_confirmation" type="password" required 
                           class="mt-1 block w-full px-3 py-3 border border-action/30 rounded-lg bg-primary/50 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-action focus:border-transparent transition-all"
                           placeholder="Confirm your password">
                </div>

                <!-- Wallet Address -->
                <div>
                    <label for="wallet_address" class="block text-sm font-medium text-white">
                        Wallet Address (Optional)
                    </label>
                    <input id="wallet_address" name="wallet_address" type="text" 
                           class="mt-1 block w-full px-3 py-3 border border-action/30 rounded-lg bg-primary/50 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-action focus:border-transparent transition-all"
                           placeholder="Enter your wallet address"
                           value="{{ old('wallet_address') }}">
                </div>

                <!-- Language -->
                <div>
                    <label for="language" class="block text-sm font-medium text-white">
                        Language Preference
                    </label>
                    <select id="language" name="language" 
                            class="mt-1 block w-full px-3 py-3 border border-action/30 rounded-lg bg-primary/50 text-white focus:outline-none focus:ring-2 focus:ring-action focus:border-transparent transition-all">
                        <option value="en" {{ old('language') == 'en' ? 'selected' : '' }}>English</option>
                        <option value="es" {{ old('language') == 'es' ? 'selected' : '' }}>Español</option>
                        <option value="fr" {{ old('language') == 'fr' ? 'selected' : '' }}>Français</option>
                        <option value="de" {{ old('language') == 'de' ? 'selected' : '' }}>Deutsch</option>
                    </select>
                </div>

                <!-- Referrer ID -->
                <div>
                    <label for="referrer_id" class="block text-sm font-medium text-white">
                        Referrer ID (Optional)
                    </label>
                    <input id="referrer_id" name="referrer_id" type="text" 
                           class="mt-1 block w-full px-3 py-3 border border-action/30 rounded-lg bg-primary/50 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-action focus:border-transparent transition-all"
                           placeholder="Enter referrer ID if you have one"
                           value="{{ old('referrer_id') ?? request('ref') }}">
                    @if(request('ref'))
                        <p class="mt-1 text-xs text-action/80">You were referred by someone!</p>
                    @endif
                </div>
            </div>

            <div>
                <button type="submit" 
                        class="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-primary bg-action hover:bg-action/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-action transition-all transform hover:scale-105">
                    Create Account
                </button>
            </div>

            <div class="text-center">
                <p class="text-sm text-white/80">
                    Already have an account? 
                    <a href="{{ route('login') }}" class="font-medium text-action hover:text-action/80 transition-colors">
                        Sign in here
                    </a>
                </p>
            </div>
        </form>
    </div>
</div>
@endsection
