@extends('layouts.app')

@section('title', 'Edit Profile - NetOnYou')

@section('content')
<div class="min-h-screen bg-gray-50">
    <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <!-- Page Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900">Edit Profile</h1>
            <p class="text-gray-600 mt-2">Update your personal information</p>
        </div>

        <!-- Profile Edit Form -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-6">Profile Information</h2>

            @if($errors->any())
                <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg">
                    <ul class="list-disc list-inside">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{ route('profile.update') }}">
                @csrf
                @method('PUT')

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Name -->
                    <div class="md:col-span-2">
                        <label for="name" class="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                        <input type="text" id="name" name="name" value="{{ old('name', $user->name) }}" required
                               class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#1d003f] focus:border-transparent">
                    </div>

                    <!-- Email (Read-only) -->
                    <div class="md:col-span-2">
                        <label for="email" class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                        <input type="email" id="email" value="{{ $user->email }}" disabled
                               class="w-full border border-gray-300 rounded-lg px-3 py-2 bg-gray-50 text-gray-500 cursor-not-allowed">
                        <p class="text-sm text-gray-500 mt-1">Email address cannot be changed</p>
                    </div>

                    <!-- Language -->
                    <div>
                        <label for="language" class="block text-sm font-medium text-gray-700 mb-2">Language</label>
                        <select id="language" name="language" required
                                class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#1d003f] focus:border-transparent">
                            <option value="en" {{ old('language', $user->language) === 'en' ? 'selected' : '' }}>English</option>
                            <option value="es" {{ old('language', $user->language) === 'es' ? 'selected' : '' }}>Español</option>
                            <option value="fr" {{ old('language', $user->language) === 'fr' ? 'selected' : '' }}>Français</option>
                            <option value="de" {{ old('language', $user->language) === 'de' ? 'selected' : '' }}>Deutsch</option>
                            <option value="it" {{ old('language', $user->language) === 'it' ? 'selected' : '' }}>Italiano</option>
                        </select>
                    </div>

                    <!-- Wallet Address -->
                    <div>
                        <label for="wallet_address" class="block text-sm font-medium text-gray-700 mb-2">Wallet Address</label>
                        <input type="text" id="wallet_address" name="wallet_address" value="{{ old('wallet_address', $user->wallet_address) }}"
                               placeholder="0x..."
                               class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#1d003f] focus:border-transparent">
                        <p class="text-sm text-gray-500 mt-1">Optional - Your cryptocurrency wallet address</p>
                    </div>
                </div>

                <div class="flex justify-end space-x-4 mt-8">
                    <a href="{{ route('dashboard') }}" class="bg-gray-300 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-400 transition-colors">
                        Cancel
                    </a>
                    <button type="submit" class="bg-[#1d003f] text-white px-6 py-2 rounded-lg font-medium hover:bg-[#2a0057] transition-colors">
                        Update Profile
                    </button>
                </div>
            </form>
        </div>

        <!-- Change Password Section -->
        <div class="bg-white rounded-lg shadow-md p-6 mt-6">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-semibold text-gray-800">Password</h2>
                <a href="{{ route('profile.change-password') }}" class="bg-[#1d003f] text-white px-4 py-2 rounded-lg font-medium hover:bg-[#2a0057] transition-colors">
                    Change Password
                </a>
            </div>
            <p class="text-gray-600">Keep your account secure by using a strong password and updating it regularly.</p>
        </div>
    </div>
</div>
@endsection

