#!/bin/bash

echo "=========================================="
echo "Net On You - Quick Deployment"
echo "=========================================="

# Set permissions
echo "Setting file permissions..."
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644 {} \;
chmod -R 775 storage/
chmod -R 775 bootstrap/cache/
chmod +x artisan

# Install dependencies
echo "Installing PHP dependencies..."
composer install --optimize-autoloader --no-dev

# Generate application key
echo "Generating application key..."
php artisan key:generate

# Clear and optimize caches
echo "Optimizing for production..."
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Set up storage link
echo "Setting up storage link..."
php artisan storage:link

echo "=========================================="
echo "✅ Deployment completed successfully!"
echo "=========================================="
echo ""
echo "🔐 Admin Access:"
echo "   URL: https://yourdomain.com/admin/login"
echo "   Email: admin@netonyou.com"
echo "   Password: admin123"
echo ""
echo "👤 User 1 (Alex Johnson):"
echo "   Email: alex.johnson@example.com"
echo "   Password: password123"
echo "   Referral Code: ALEX2024"
echo "=========================================="
