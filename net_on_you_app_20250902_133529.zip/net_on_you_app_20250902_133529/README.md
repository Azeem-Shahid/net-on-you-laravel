# Net On You - Quick Deployment

## 🚀 Deployment Steps

### 1. Upload Files
Upload all files to your cPanel `public_html` directory

### 2. Run Deployment Script
```bash
chmod +x deploy.sh
./deploy.sh
```

### 3. Set Up Cron Jobs
```bash
chmod +x setup_cron.sh
./setup_cron.sh
```

## 🔐 Login Credentials

### Admin
- **URL**: `https://yourdomain.com/admin/login`
- **Email**: `admin@netonyou.com`
- **Password**: `admin123`

### User 1 (Alex Johnson)
- **Email**: `alex.johnson@example.com`
- **Password**: `password123`
- **Referral Code**: `ALEX2024`

## 📋 What's Included
- Complete Laravel application
- All dependencies and vendor files
- Automated deployment script
- Cron jobs setup guide
- User 1 with 25+ referrals and commission tracking
