<?php

return [
    'disable_email_verification' => true,
];

