#!/bin/bash

echo "=========================================="
echo "Net On You - Cron Jobs Setup"
echo "=========================================="

echo "📋 Add these cron jobs to your cPanel:"
echo ""
echo "1. Process payments every 6 hours:"
echo "   0 */6 * * * cd /home/your_username/public_html && php artisan payments:process"
echo ""
echo "2. Calculate commissions daily:"
echo "   0 0 * * * cd /home/your_username/public_html && php artisan commissions:calculate"
echo ""
echo "3. Send email notifications every 2 hours:"
echo "   0 */2 * * * cd /home/your_username/public_html && php artisan emails:send"
echo ""
echo "⚠️  Replace 'your_username' with your actual cPanel username"
echo "=========================================="
