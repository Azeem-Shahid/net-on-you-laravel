#!/bin/bash

echo "Net On You - Quick Setup"
echo "========================"

# Set permissions
echo "Setting permissions..."
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644 {} \;
chmod -R 775 storage/
chmod -R 775 bootstrap/cache/
chmod +x artisan

# Install dependencies
echo "Installing dependencies..."
composer install --optimize-autoloader --no-dev

# Generate key
echo "Generating application key..."
php artisan key:generate

# Run migrations and seeders
echo "Setting up database..."
php artisan migrate --force
php artisan db:seed --force

# Optimize
echo "Optimizing for production..."
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
php artisan config:cache
php artisan route:cache
php artisan view:cache

echo "Setup completed!"
echo "Admin: https://yourdomain.com/admin/login (admin@netonyou.com / admin123)"
echo "User 1: https://yourdomain.com/login (alex.johnson@example.com / password123)"
