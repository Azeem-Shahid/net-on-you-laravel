-- Net On You Database Structure
-- This file contains the database structure for Net On You

-- Note: This is a reference file. The actual database will be created
-- by running Laravel migrations: php artisan migrate

-- Key tables that will be created:
-- - users (with referral relationships)
-- - referrals (referral tracking)
-- - commissions (commission calculations)
-- - transactions (payment history)
-- - subscriptions (subscription management)
-- - magazines (content library)
-- - email_templates (email system)
-- - languages (multi-language support)
-- - contracts (legal documents)
-- - admins (admin accounts)
-- - settings (system configuration)
-- - payout_batches (payout management)

-- Dummy data will be created by running:
-- php artisan db:seed --force
