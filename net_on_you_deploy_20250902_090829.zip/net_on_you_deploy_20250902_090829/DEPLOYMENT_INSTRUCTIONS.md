# Net On You - Deployment Instructions

## Quick Setup

### 1. Upload Files
1. Upload all files to your cPanel public_html directory
2. Extract if uploaded as ZIP

### 2. Set Permissions
```bash
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644 {} \;
chmod -R 775 storage/
chmod -R 775 bootstrap/cache/
chmod +x artisan
```

### 3. Install Dependencies
```bash
composer install --optimize-autoloader --no-dev
```

### 4. Environment Setup
```bash
# Copy environment file
cp .env.example .env

# Generate application key
php artisan key:generate

# Update database settings in .env file
```

### 5. Database Setup
```bash
# Run migrations
php artisan migrate --force

# Run seeders to create dummy data
php artisan db:seed --force
```

### 6. Optimize for Production
```bash
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

## Admin Access

- **URL**: https://yourdomain.com/admin/login
- **Email**: admin@netonyou.com
- **Password**: admin123

## User 1 Referral Network

- **Email**: alex.johnson@example.com
- **Password**: password123
- **Features**: 25+ referrals, commission tracking, complete transaction history

## Cron Jobs Setup

Add these to your cPanel Cron Jobs:

```bash
# Process payments every 6 hours
0 */6 * * * cd /home/your_username/public_html && php artisan payments:process

# Calculate commissions daily
0 0 * * * cd /home/your_username/public_html && php artisan commissions:calculate

# Send email notifications every 2 hours
0 */2 * * * cd /home/your_username/public_html && php artisan emails:send
```

## Features Included

✅ Complete referral system with User 1 network  
✅ Multi-level commission tracking  
✅ Payment processing with multiple gateways  
✅ Email templates and notifications  
✅ Multi-language support (4 languages)  
✅ Magazine management system  
✅ Admin dashboard with full functionality  
✅ Subscription management  
✅ Payout system  
✅ Security policies  
✅ Audit logging  
✅ System monitoring  

## Support

Refer to the documentation files for detailed setup instructions.
